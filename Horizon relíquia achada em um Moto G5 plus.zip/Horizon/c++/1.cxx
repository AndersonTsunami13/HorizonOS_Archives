#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <thread>
#include <chrono>
#include <ctime>

using namespace std;

// ================== EFEITO TEXTO ==================
void escreverLento(string texto, int delay = 20) {
    for (char c : texto) {
        cout << c << flush;
        this_thread::sleep_for(chrono::milliseconds(delay));
    }
    cout << endl;
}

// ================== SISTEMA ==================
map<string, vector<string>> sistema;
map<string, string> arquivos;
string pastaAtual = "/";

// ================== INICIAR SISTEMA ==================
void iniciarSistema() {
    sistema["/"] = {"docs", "jogos", "sistema"};
    sistema["/docs"] = {};
    sistema["/jogos"] = {};
    sistema["/sistema"] = {};
}

// ================== COMANDOS ==================
void listar() {
    escreverLento("Conteudo:");
    for (auto item : sistema[pastaAtual]) {
        cout << "- " << item << endl;
    }
}

void criarPasta(string nome) {
    sistema[pastaAtual].push_back(nome);
    sistema[pastaAtual + "/" + nome] = {};
    escreverLento("Pasta criada.");
}

void criarArquivo(string nome) {
    sistema[pastaAtual].push_back(nome);
    arquivos[pastaAtual + "/" + nome] = "";
    escreverLento("Arquivo criado.");
}

void editarArquivo(string nome) {
    string caminho = pastaAtual + "/" + nome;
    string texto;

    escreverLento("Digite o conteúdo:");
    cin.ignore();
    getline(cin, texto);

    arquivos[caminho] = texto;
    escreverLento("Salvo.");
}

void lerArquivo(string nome) {
    string caminho = pastaAtual + "/" + nome;

    if (arquivos.count(caminho)) {
        escreverLento("Conteudo:");
        cout << arquivos[caminho] << endl;
    } else {
        escreverLento("Arquivo nao encontrado.");
    }
}

void verHora() {
    time_t agora = time(0);
    char* dt = ctime(&agora);
    cout << "Hora atual: " << dt;
}

// ================== NAVEGAÇÃO ==================
void mudarPasta(string nome) {
    if (nome == "..") {
        if (pastaAtual != "/") {
            size_t pos = pastaAtual.find_last_of('/');
            pastaAtual = (pos == 0) ? "/" : pastaAtual.substr(0, pos);
        }
    } else {
        string novo = (pastaAtual == "/") ? "/" + nome : pastaAtual + "/" + nome;
        if (sistema.count(novo)) {
            pastaAtual = novo;
        } else {
            escreverLento("Pasta nao encontrada.");
        }
    }
}

// ================== LOGIN ==================
bool login() {
    string user, pass;

    escreverLento("=== Horizon System ===");
    escreverLento("Login:");
    cin >> user;

    escreverLento("Senha:");
    cin >> pass;

    if (user == "admin" && pass == "1234") {
        escreverLento("Acesso permitido.");
        return true;
    } else {
        escreverLento("Acesso negado.");
        return false;
    }
}

// ================== TERMINAL ==================
void terminal() {
    string comando;

    while (true) {
        cout << "Horizon:" << pastaAtual << "> ";
        cin >> comando;

        if (comando == "ls") {
            listar();
        }
        else if (comando == "mkdir") {
            string nome;
            cin >> nome;
            criarPasta(nome);
        }
        else if (comando == "touch") {
            string nome;
            cin >> nome;
            criarArquivo(nome);
        }
        else if (comando == "edit") {
            string nome;
            cin >> nome;
            editarArquivo(nome);
        }
        else if (comando == "cat") {
            string nome;
            cin >> nome;
            lerArquivo(nome);
        }
        else if (comando == "cd") {
            string nome;
            cin >> nome;
            mudarPasta(nome);
        }
        else if (comando == "hora") {
            verHora();
        }
        else if (comando == "help") {
            escreverLento("Comandos:");
            cout << "ls | mkdir | touch | edit | cat | cd | hora | sair\n";
        }
        else if (comando == "sair") {
            escreverLento("Encerrando sistema...");
            break;
        }
        else {
            escreverLento("Comando desconhecido.");
        }
    }
}

// ================== MAIN ==================
int main() {
    iniciarSistema();

    if (login()) {
        escreverLento("Carregando sistema...");
        terminal();
    }

    return 0;
}