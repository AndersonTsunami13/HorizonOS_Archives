import tkinter as tk
from tkinter import messagebox

# Inicializa a janela raiz (precisa disso pra funcionar)
root = tk.Tk()
root.withdraw()  # Oculta a janela principal (não queremos ela)

# Várias janelas popup interativas
messagebox.showinfo("Aviso", "Isso é uma notificação simples!")  # Info normal

res1 = messagebox.askokcancel("Confirmação", "Deseja prosseguir?")
print("askokcancel:", res1)

res2 = messagebox.askquestion("Pergunta", "Você quer pizza?")
print("askquestion:", res2)

res3 = messagebox.askretrycancel("Erro", "Conexão falhou. Tentar de novo?")
print("askretrycancel:", res3)

res4 = messagebox.askyesno("Decisão", "Você é um verdadeiro dev?")
print("askyesno:", res4)

res5 = messagebox.askyesnocancel("Escolha crítica", "Salvar alterações antes de sair?")
print("askyesnocancel:", res5)
