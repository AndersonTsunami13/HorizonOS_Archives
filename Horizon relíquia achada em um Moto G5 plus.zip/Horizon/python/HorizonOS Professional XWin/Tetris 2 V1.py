import pygame
import random
import sys

pygame.init()
clock = pygame.time.Clock()

# Tela
largura, altura = 1350, 940
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Horizon Tetris Mobile")
fps = 60

# Cores
PRETO = (0, 0, 0)
CINZA = (50, 50, 50)
BRANCO = (255, 255, 255)
CORES = [(0, 255, 255), (0, 255, 0), (255, 0, 0), (255, 255, 0),
         (255, 165, 0), (0, 0, 255), (128, 0, 128)]

# Grade
colunas, linhas = 10, 20
bloco = 40
esquerda = largura // 2 - colunas * bloco // 2
topo = altura // 2 - linhas * bloco // 2

# Peças
formas = {
    'I': [[1, 1, 1, 1]],
    'O': [[1, 1], [1, 1]],
    'T': [[0, 1, 0], [1, 1, 1]],
    'S': [[0, 1, 1], [1, 1, 0]],
    'Z': [[1, 1, 0], [0, 1, 1]],
    'J': [[1, 0, 0], [1, 1, 1]],
    'L': [[0, 0, 1], [1, 1, 1]]
}

class Peca:
    def __init__(self):
        self.forma = random.choice(list(formas.values()))
        self.cor = random.choice(CORES)
        self.x = colunas // 2 - len(self.forma[0]) // 2
        self.y = 0

    def girar(self):
        self.forma = [list(row) for row in zip(*self.forma[::-1])]

def desenhar_grade(travas):
    for y in range(linhas):
        for x in range(colunas):
            cor = PRETO
            if (x, y) in travas:
                cor = travas[(x, y)]
            pygame.draw.rect(tela, cor, (esquerda + x * bloco, topo + y * bloco, bloco, bloco))
            pygame.draw.rect(tela, CINZA, (esquerda + x * bloco, topo + y * bloco, bloco, bloco), 1)

def desenhar_peca(peca):
    for y, linha in enumerate(peca.forma):
        for x, val in enumerate(linha):
            if val:
                pygame.draw.rect(tela, peca.cor,
                                 (esquerda + (peca.x + x) * bloco, topo + (peca.y + y) * bloco, bloco, bloco))
                pygame.draw.rect(tela, BRANCO,
                                 (esquerda + (peca.x + x) * bloco, topo + (peca.y + y) * bloco, bloco, bloco), 1)

def mover(peca, dx, dy, travas):
    novo_x = peca.x + dx
    novo_y = peca.y + dy
    for y, linha in enumerate(peca.forma):
        for x, val in enumerate(linha):
            if val:
                px = novo_x + x
                py = novo_y + y
                if px < 0 or px >= colunas or py >= linhas or (px, py) in travas:
                    return False
    peca.x = novo_x
    peca.y = novo_y
    return True

def rotacionar(peca, travas):
    original = peca.forma
    peca.girar()
    if not mover(peca, 0, 0, travas):
        peca.forma = original

def fixar(peca, travas):
    for y, linha in enumerate(peca.forma):
        for x, val in enumerate(linha):
            if val:
                travas[(peca.x + x, peca.y + y)] = peca.cor

def limpar_linhas(travas):
    linhas_removidas = 0
    for y in range(linhas):
        if all((x, y) in travas for x in range(colunas)):
            linhas_removidas += 1
            for x in range(colunas):
                del travas[(x, y)]
            for k in sorted(travas.copy(), key=lambda t: t[1], reverse=True):
                xk, yk = k
                if yk < y:
                    travas[(xk, yk + 1)] = travas.pop(k)
    return linhas_removidas

# Botões de toque
botao_esq = pygame.Rect(50, altura - 140, 100, 80)
botao_dir = pygame.Rect(180, altura - 140, 100, 80)
botao_baixo = pygame.Rect(largura - 280, altura - 140, 100, 80)
botao_giro = pygame.Rect(largura - 140, altura - 140, 100, 80)

def desenhar_botoes():
    fonte = pygame.font.SysFont("Arial", 25)
    botoes = [
        (botao_esq, "LEFT"),
        (botao_dir, "RIGHT"),
        (botao_baixo, "DOWN"),
        (botao_giro, "TURN")
    ]
    for botao, txt in botoes:
        pygame.draw.rect(tela, CINZA, botao)
        texto = fonte.render(txt, True, BRANCO)
        tela.blit(texto, (botao.x + 20, botao.y + 25))

def main():
    trava = {}
    peca = Peca()
    proxima = Peca()
    tempo_queda = 0
    delay = 500
    pontos = 0

    rodando = True
    while rodando:
        tela.fill(PRETO)
        tempo_queda += clock.get_rawtime()
        clock.tick(fps)

        if tempo_queda > delay:
            if not mover(peca, 0, 1, trava):
                fixar(peca, trava)
                pontos += limpar_linhas(trava) * 100
                peca = proxima
                proxima = Peca()
                if not mover(peca, 0, 0, trava):
                    print("GAME OVER")
                    rodando = False
            tempo_queda = 0

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.MOUSEBUTTONDOWN:
                if botao_esq.collidepoint(e.pos): mover(peca, -1, 0, trava)
                if botao_dir.collidepoint(e.pos): mover(peca, 1, 0, trava)
                if botao_baixo.collidepoint(e.pos): mover(peca, 0, 1, trava)
                if botao_giro.collidepoint(e.pos): rotacionar(peca, trava)

        desenhar_grade(trava)
        desenhar_peca(peca)
        desenhar_botoes()

        # Pontuação
        fonte = pygame.font.SysFont("Arial", 30)
        texto = fonte.render(f"Pontos: {pontos}", True, BRANCO)
        tela.blit(texto, (20, 20))

        pygame.display.update()

main()