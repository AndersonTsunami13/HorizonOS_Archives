import pygame
import random
import sys

# Inicializa Pygame
pygame.init()

# Tela
LARGURA, ALTURA = 800, 600
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Tela Quebra-Tela - Hardcore Mode")

# Cores
VERMELHO = (255, 0, 0)
VERDE = (0, 255, 0)
AZUL = (0, 0, 255)
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)

# Fonte
fonte = pygame.font.SysFont(None, 40)

# Bloco
BLOCO_LARGURA = 50
BLOCO_ALTURA = 50
VEL_MIN = 2
VEL_MAX = 5

class Bloco:
    def __init__(self, cor):
        self.cor = cor
        self.x = random.randint(0, LARGURA - BLOCO_LARGURA)
        self.y = -BLOCO_ALTURA
        self.vel = random.randint(VEL_MIN, VEL_MAX)

    def mover(self):
        self.y += self.vel

    def desenhar(self):
        pygame.draw.rect(tela, self.cor, (self.x, self.y, BLOCO_LARGURA, BLOCO_ALTURA))

    def colidir(self, pos):
        x, y = pos
        return self.x <= x <= self.x + BLOCO_LARGURA and self.y <= y <= self.y + BLOCO_ALTURA

# Variáveis do jogo
blocos = []
pontos = 0
blocos_vermelhos_clicados = 0
limite_negativo = -50

# Quantidade inicial de blocos
qtd_vermelho = 3
qtd_verde = 2
qtd_azul = 2

# Função para gerar blocos novos
def gerar_blocos():
    global blocos
    blocos.clear()
    for _ in range(qtd_vermelho):
        blocos.append(Bloco(VERMELHO))
    for _ in range(qtd_verde):
        blocos.append(Bloco(VERDE))
    for _ in range(qtd_azul):
        blocos.append(Bloco(AZUL))

gerar_blocos()

clock = pygame.time.Clock()
rodando = True

while rodando:
    tela.fill(PRETO)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False
        elif evento.type == pygame.MOUSEBUTTONDOWN:
            pos_mouse = pygame.mouse.get_pos()
            for bloco in blocos[:]:  # cópia para poder remover
                if bloco.colidir(pos_mouse):
                    if bloco.cor == VERMELHO:
                        pontos += 5
                        blocos_vermelhos_clicados += 1
                    else:
                        pontos -= 3
                    blocos.remove(bloco)

                    # Ajusta a quantidade de blocos de acordo com blocos vermelhos clicados
                    qtd_vermelho = min(20, 3 + blocos_vermelhos_clicados // 2)
                    qtd_verde = min(30, 2 + blocos_vermelhos_clicados)
                    qtd_azul = min(30, 2 + blocos_vermelhos_clicados)

                    # Regenera blocos
                    gerar_blocos()
                    break

    # Move e desenha blocos
    for bloco in blocos[:]:
        bloco.mover()
        if bloco.y > ALTURA:
            blocos.remove(bloco)
            # Se um bloco vermelho cair sem ser clicado, perde pontos
            if bloco.cor == VERMELHO:
                pontos -= 5
            # Se um bloco verde ou azul cair, sem penalidade
            # pode ajustar depois se quiser
            gerar_blocos()
        else:
            bloco.desenhar()

    # Desenha pontuação
    texto_pontos = fonte.render(f"Pontos: {pontos}", True, BRANCO)
    tela.blit(texto_pontos, (10, 10))

    # Checa condição de game over
    if pontos <= limite_negativo:
        texto_gameover = fonte.render("GAME OVER! Você perdeu 😵", True, VERMELHO)
        tela.blit(texto_gameover, (LARGURA // 2 - 200, ALTURA // 2))
        pygame.display.flip()
        pygame.time.wait(3000)
        rodando = False

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()