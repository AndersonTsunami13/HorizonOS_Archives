import pygame
import random

pygame.init()

# Configurações da tela
largura = 400
altura = 300
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Horizon Dino Runner 🦖")

# Cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)

# Clock
clock = pygame.time.Clock()
fps = 60

# Jogador
jogador_largura = 30
jogador_altura = 30
jogador_x = 50
jogador_y = altura - jogador_altura
jogador_velocidade_y = 0
no_chao = True
gravidade = 1

# Obstáculos
obstaculos = []
tempo_obstaculo = 0
intervalo_obstaculo = 60

# Botão de pulo
botao_pulo = pygame.Rect(largura - 120, altura - 80, 100, 50)

# Loop principal
rodando = True
while rodando:
    tela.fill(PRETO)
    pygame.draw.rect(tela, (255, 255, 255), (0, 0, largura, altura), 3)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False
        if evento.type == pygame.MOUSEBUTTONDOWN:
            if botao_pulo.collidepoint(evento.pos):
                if no_chao:
                    jogador_velocidade_y = -15
                    no_chao = False

    # Física do jogador
    jogador_y += jogador_velocidade_y
    jogador_velocidade_y += gravidade

    if jogador_y >= altura - jogador_altura:
        jogador_y = altura - jogador_altura
        no_chao = True

    # Obstáculos
    tempo_obstaculo += 1
    if tempo_obstaculo > intervalo_obstaculo:
        tempo_obstaculo = 0
        altura_obs = random.randint(20, 40)
        obstaculos.append(pygame.Rect(largura, altura - altura_obs, 20, altura_obs))

    for obs in obstaculos:
        obs.x -= 5
        pygame.draw.rect(tela, VERMELHO, obs)

    # Colisão
    jogador = pygame.Rect(jogador_x, jogador_y, jogador_largura, jogador_altura)
    pygame.draw.rect(tela, VERDE, jogador)

    for obs in obstaculos:
        if jogador.colliderect(obs):
            print("Você perdeu!")
            rodando = False

    # Botão
    pygame.draw.rect(tela, BRANCO, botao_pulo)
    fonte = pygame.font.SysFont(None, 24)
    texto = fonte.render("PULAR", True, PRETO)
    tela.blit(texto, (botao_pulo.x + 20, botao_pulo.y + 15))

    pygame.display.flip()
    clock.tick(fps)

pygame.quit()