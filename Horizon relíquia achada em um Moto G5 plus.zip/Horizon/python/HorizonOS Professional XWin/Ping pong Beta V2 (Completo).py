import pygame
import random
import sys

# Ping Pong Beta V2
# Desenvolvedor Anderson Tsunami
# Jogo para HorizonOS

pygame.init()
largura = 1350
altura = 940
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Ping Pong Mobile")

BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)

clock = pygame.time.Clock()
fps = 120

bola_raio = 15

# Cria bolas
bolas = []
for _ in range(5):
    bola = {
        'x': largura // 2,
        'y': altura // 2,
        'vel_x': 5 * random.choice([-1, 1, -2, 2, -3, 3]),
        'vel_y': 7,
        'raio': bola_raio
    }
    bolas.append(bola)

raquete_largura = 1300
raquete_altura = 20
raquete_x = (largura - raquete_largura) // 2
raquete_y = altura - 60

pontos = 0
fonte = pygame.font.SysFont("Arial", 30)

rodando = True
while rodando:
    clock.tick(fps)
    tela.fill(PRETO)
    pygame.draw.rect(tela, BRANCO, (0, 0, largura, altura), 3)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False
        if evento.type == pygame.MOUSEMOTION:
            raquete_x = evento.pos[0] - raquete_largura // 2

    for bola in bolas:
        bola['x'] += bola['vel_x']
        bola['y'] += bola['vel_y']

        if bola['x'] - bola['raio'] <= 0 or bola['x'] + bola['raio'] >= largura:
            bola['vel_x'] *= -1

        if bola['y'] - bola['raio'] <= 0:
            bola['vel_y'] *= -1

        if (raquete_y <= bola['y'] + bola['raio'] <= raquete_y + raquete_altura and
            raquete_x <= bola['x'] <= raquete_x + raquete_largura):
            bola['vel_y'] *= -1
            pontos += 1
            
            nova_bola = {
                'x': largura // 2,
                'y': altura // 2,
                'vel_x': 5 * random.choice([-1, 1, -2, 2, -3, 3]),
                'vel_y': 7,
                'raio': bola_raio
            }
            bolas.append(nova_bola)

        if bola['y'] > altura:
            bola['x'] = largura // 2
            bola['y'] = altura // 2
            bola['vel_x'] = 5 * random.choice([-1, 1, -2, 2, -3, 3, -4, 4, -5, 5, -6, 6, -7, 7])
            bola['vel_y'] = 9

        pygame.draw.circle(tela, BRANCO, (int(bola['x']), int(bola['y'])), bola['raio'])

    pygame.draw.rect(tela, BRANCO, (raquete_x, raquete_y, raquete_largura, raquete_altura))

    texto = fonte.render(f"Pontos: {pontos}", True, BRANCO)
    tela.blit(texto, (10, 10))
    
    bolas_visiveis = sum(1 for bola in bolas if 0 <= bola['y'] <= altura)
    texto_bolas = fonte.render(f"Bolas visíveis: {bolas_visiveis}", True, BRANCO)
    tela.blit(texto_bolas, (10, 50))  # Agora sim vai aparecer!
    
    fps_atual = int(clock.get_fps())
    texto_fps = fonte.render(f"FPS: {fps_atual}", True, BRANCO)
    tela.blit(texto_fps, (10, 90))  # Mais abaixo dos outros

    pygame.display.update()

pygame.quit()
sys.exit()