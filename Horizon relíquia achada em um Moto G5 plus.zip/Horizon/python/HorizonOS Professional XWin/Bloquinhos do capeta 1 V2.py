import pygame
import random
import sys
import os

# Bloquinhos do Capeta 1 V2 - O Retorno do Inferno
# Desenvolvido por Anderson Tsunami
# Game com fundo animado, música (comentada), botões e game over interativo

pygame.init()

# Configurações da tela
info_tela = pygame.display.Info()
largura = info_tela.current_w
altura = info_tela.current_h
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Bloquinhos do Capeta 😈🔥 V2")

# Cores
CINZA_ESCURO = (30, 30, 30)
VERMELHO = (200, 0, 0)
VERDE = (0, 200, 0)
BRANCO = (255, 255, 255)
AMARELO = (255, 255, 0)
VERMELHO_FOGO = (255, 60, 0)

def get_cor_bloco(blocos_eliminados):
    if blocos_eliminados <= 20:
        return BRANCO
    elif blocos_eliminados <= 40:
        return VERMELHO
    elif blocos_eliminados <= 60:
        return AMARELO
    elif blocos_eliminados <= 80:
        return (255, 140, 0)  # Laranja
    else:
        return (255, 0, 255)  # Roxo infernal

# Fonte
fonte = pygame.font.SysFont("arial", 28)
fonte_grande = pygame.font.SysFont("arial", 72)
fonte_pequena = pygame.font.SysFont("arial", 36)

# Bloco
largura_bloco = 130
altura_bloco = 130

# Game variables
blocos = []
velocidade = 2
pontos = 0
blocos_eliminados = 0
spawn_tempo = 1000  # ms entre blocos
ultimo_spawn = pygame.time.get_ticks()

# Fundo estrelas
num_estrelas = 100
estrelas = []
for _ in range(num_estrelas):
    x = random.randint(0, largura)
    y = random.randint(0, altura)
    tamanho = random.randint(1, 3)
    estrelas.append([x, y, tamanho])

clock = pygame.time.Clock()

# Partículas de fogo no fundo
class FogoParticle:
    def __init__(self):
        self.x = random.randint(0, largura)
        self.y = random.randint(altura - 100, altura)
        self.vel_y = random.uniform(0.5, 1.5)
        self.tamanho = random.randint(2, 5)

    def update(self):
        self.y -= self.vel_y
        if self.y < 0:
            self.x = random.randint(0, largura)
            self.y = random.randint(altura - 100, altura)
            self.vel_y = random.uniform(0.5, 1.5)
            self.tamanho = random.randint(2, 5)

    def draw(self, surface):
        pygame.draw.circle(surface, VERMELHO_FOGO, (int(self.x), int(self.y)), self.tamanho)
        
particulas = [FogoParticle() for _ in range(100)]

# Partículas brancas ao clicar no bloco
particulas_brancas = []

def criar_particulas(x, y, quantidade=10):
    for _ in range(quantidade):
        particula = {
            "x": x + random.randint(-20, 20),
            "y": y + random.randint(-20, 20),
            "tamanho": random.randint(4, 7),
            "vida": random.randint(20, 30),
            "vel_x": random.uniform(-1.5, 1.5),
            "vel_y": random.uniform(-1.5, 1.5)
        }
        particulas_brancas.append(particula)

def atualizar_particulas():
    for p in particulas_brancas[:]:
        p["x"] += p["vel_x"]
        p["y"] += p["vel_y"]
        p["vida"] -= 1
        p["tamanho"] -= 0.15
        if p["vida"] <= 0 or p["tamanho"] <= 0:
            particulas_brancas.remove(p)

def desenhar_particulas():
    for p in particulas_brancas:
        if p["tamanho"] > 0:
            pygame.draw.circle(tela, BRANCO, (int(p["x"]), int(p["y"])), int(p["tamanho"]))

class BlocoEspecial(pygame.Rect):
    def __init__(self, x, y, largura, altura, tipo):
        super().__init__(x, y, largura, altura)
        self.tipo = tipo  # 'armadilha', 'congelante', 'bonus'

    def cor(self):
        if self.tipo == 'armadilha':
            return (128, 0, 0)  # vermelho escuro
        elif self.tipo == 'congelante':
            return (0, 128, 255)  # azul claro
        elif self.tipo == 'bonus':
            return (255, 215, 0)  # dourado
        else:
            return VERMELHO

def criar_bloco():
    x = random.randint(0, largura - largura_bloco)
    y = -altura_bloco
    chance = random.random()
    if chance < 0.1:
        tipo = random.choice(['armadilha', 'congelante', 'bonus'])
        blocos.append(BlocoEspecial(x, y, largura_bloco, altura_bloco, tipo))
    else:
        blocos.append(pygame.Rect(x, y, largura_bloco, altura_bloco))

def desenhar_texto(texto, x, y, cor=BRANCO):
    render = fonte.render(texto, True, cor)
    tela.blit(render, (x, y))

def atualizar_estrelas():
    for estrela in estrelas:
        estrela[1] += 1
        if estrela[1] > altura:
            estrela[0] = random.randint(0, largura)
            estrela[1] = 0

def desenhar_estrelas():
    for estrela in estrelas:
        pygame.draw.circle(tela, BRANCO, (estrela[0], estrela[1]), estrela[2])

def parar_musica():
    pygame.mixer.music.stop()

def game_over():
    global blocos, pontos, velocidade, spawn_tempo, blocos_eliminados
    parar_musica()
    tela.fill(CINZA_ESCURO)
    desenhar_texto("Que triste mano 😔 você perdeu!", largura // 2 - 200, altura // 2 - 70, AMARELO)
    desenhar_texto(f"Pontos: {pontos}", largura // 2 - 70, altura // 2 - 30, AMARELO)
    desenhar_texto("Tente de novo? Aperte o botão VERDE", largura // 2 - 230, altura // 2 + 10, VERDE)
    desenhar_texto("Ou aperte o botão VERMELHO para sair", largura // 2 - 230, altura // 2 + 50, VERMELHO)

    # Desenhar botões (retângulos no fundo)
    btn_vermelho = pygame.Rect(largura // 2 - 250, altura // 2 + 80, 150, 60)
    btn_verde = pygame.Rect(largura // 2 + 100, altura // 2 + 80, 150, 60)
    pygame.draw.rect(tela, VERMELHO, btn_vermelho)
    pygame.draw.rect(tela, VERDE, btn_verde)
    desenhar_texto("SAIR", btn_vermelho.x + 45, btn_vermelho.y + 15, BRANCO)
    desenhar_texto("TENTAR", btn_verde.x + 40, btn_verde.y + 15, BRANCO)

    pygame.display.flip()

    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if btn_vermelho.collidepoint(pos):
                    pygame.quit()
                    sys.exit()
                elif btn_verde.collidepoint(pos):
                    esperando = False
                    reiniciar_jogo()

def reiniciar_jogo():
    global blocos, pontos, velocidade, spawn_tempo, blocos_eliminados
    blocos = []
    pontos = 0
    blocos_eliminados = 0
    velocidade = 2
    spawn_tempo = 1000

def menu():
    rodando_menu = True
    while rodando_menu:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif evento.type == pygame.KEYDOWN or evento.type == pygame.MOUSEBUTTONDOWN:
                rodando_menu = False

        for p in particulas:
            p.update()

        tela.fill(CINZA_ESCURO)

        for p in particulas:
            p.draw(tela)

        titulo = fonte_grande.render("Bloquinhos do Capeta 1", True, BRANCO)
        msg = fonte_pequena.render("Toque para começar", True, BRANCO)
        tela.blit(titulo, (largura // 2 - titulo.get_width() // 2, altura // 3))
        tela.blit(msg, (largura // 2 - msg.get_width() // 2, altura // 2))

        pygame.display.flip()
        clock.tick(60)

# Tela principal
rodando = True
menu()

while rodando:
    # Fundo muda conforme pontos
    if pontos > 200:
        tela.fill((10, 10, 40))  # Azul escuro galáxia
    elif pontos > 100:
        tela.fill((0, 0, 0))     # Preto
    else:
        tela.fill(CINZA_ESCURO)  # Cinza padrão

    atualizar_estrelas()
    desenhar_estrelas()
    atualizar_particulas()
    desenhar_particulas()
    pygame.draw.rect(tela, BRANCO, (0, 0, largura, altura), 3)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False
        if evento.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            for bloco in blocos[:]:
                zona_segura = bloco.inflate(0, 30)
                if zona_segura.collidepoint(pos):
                    criar_particulas(bloco.x + largura_bloco//2, bloco.y + altura_bloco//2)
                    blocos.remove(bloco)
                    blocos_eliminados += 1
                    if isinstance(bloco, BlocoEspecial):
                        if bloco.tipo == 'armadilha':
                            pontos = max(0, pontos - 10)
                        elif bloco.tipo == 'congelante':
                            velocidade = max(1, velocidade - 1)
                        elif bloco.tipo == 'bonus':
                            pontos += 20
                        else:
                            pontos += 5
                    else:
                        pontos += 5
                    if pontos % 20 == 0:
                        velocidade += 0.5
                        if spawn_tempo > 300:
                            spawn_tempo -= 50

            btn_vermelho_fundo = pygame.Rect(50, altura - 80, 120, 60)
            btn_verde_fundo = pygame.Rect(largura - 170, altura - 80, 120, 60)

            if btn_vermelho_fundo.collidepoint(pos):
                parar_musica()
                pygame.quit()
                sys.exit()
            elif btn_verde_fundo.collidepoint(pos):
                reiniciar_jogo()

    agora = pygame.time.get_ticks()
    if agora - ultimo_spawn >= spawn_tempo:
        criar_bloco()
        ultimo_spawn = agora

    for bloco in blocos[:]:
        bloco.y += velocidade
        if bloco.y > altura:
            game_over()
            break

    cor_dos_blocos = get_cor_bloco(blocos_eliminados)
    for bloco in blocos:
        if isinstance(bloco, BlocoEspecial):
            pygame.draw.rect(tela, bloco.cor(), bloco)
        else:
            pygame.draw.rect(tela, cor_dos_blocos, bloco)

    desenhar_texto(f"Pontos: {pontos}", 10, 10)
    fps_atual = int(clock.get_fps())
    desenhar_texto(f"FPS: {fps_atual}", 10, 50)
    desenhar_texto(f"Blocos Eliminados: {blocos_eliminados}", 10, 90)

    btn_vermelho_fundo = pygame.Rect(50, altura - 80, 120, 60)
    btn_verde_fundo = pygame.Rect(largura - 170, altura - 80, 120, 60)
    pygame.draw.rect(tela, VERMELHO, btn_vermelho_fundo)
    pygame.draw.rect(tela, VERDE, btn_verde_fundo)
    desenhar_texto("SAIR", btn_vermelho_fundo.x + 35, btn_vermelho_fundo.y + 15, BRANCO)
    desenhar_texto("TENTAR", btn_verde_fundo.x + 25, btn_verde_fundo.y + 15, BRANCO)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()