# HORIZON EDITOR v0.1 - Base atualizada por GhostObserver ⚡

import time

# Dicionário central dos comandos personalizados
comandos = {}

def add_comando():
    nome = input("Nome do comando: ").strip()
    if nome in comandos:
        print(f"Comando '{nome}' já existe.\n")
        return
    conteudo = input("Ação (texto ou mensagem): ")
    comandos[nome] = conteudo
    print(f"Comando '{nome}' criado com sucesso!\n")

def listar_comandos():
    if not comandos:
        print("Nenhum comando criado ainda.\n")
        return
    print("\n=== COMANDOS PERSONALIZADOS ===")
    for nome in comandos:
        print(f"- {nome}")
    print()

def executar_comando(nome):
    if nome not in comandos:
        print(f"Comando '{nome}' não encontrado.\n")
        return
    acao = comandos[nome]
    print(f"Executando '{nome}'...\n")
    time.sleep(0.4)
    print(f"{acao}\n")

def editar_comando(nome):
    if nome not in comandos:
        print(f"Comando '{nome}' não encontrado.\n")
        return
    escolha = input("Deseja editar (e) ou deletar (d)? ").strip().lower()
    if escolha == "e":
        novo_conteudo = input("Novo conteúdo do comando: ")
        comandos[nome] = novo_conteudo
        print(f"Comando '{nome}' editado com sucesso!\n")
    elif escolha == "d":
        del comandos[nome]
        print(f"Comando '{nome}' deletado com sucesso!\n")
    else:
        print("Opção inválida.\n")

def main():
    print("=== HORIZON EDITOR v0.1 ===")
    print("Comandos: add | list | run <nome> | edit <nome> | exit\n")

    while True:
        entrada = input("> ").strip().split()

        if not entrada:
            continue

        cmd = entrada[0].lower()

        if cmd == "add":
            add_comando()

        elif cmd == "list":
            listar_comandos()

        elif cmd == "run":
            if len(entrada) < 2:
                print("Uso: run <nome>\n")
                continue
            executar_comando(entrada[1])

        elif cmd == "edit":
            if len(entrada) < 2:
                print("Uso: edit <nome>\n")
                continue
            editar_comando(entrada[1])

        elif cmd == "exit":
            print("Saindo do editor...")
            time.sleep(0.5)
            break

        else:
            print("Comando desconhecido.\n")


if __name__ == "__main__":
    main()