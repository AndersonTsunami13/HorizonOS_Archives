import tkinter as tk
import time

# Função que cria uma janela personalizada e destrói depois de X segundos
def mostrar_mensagem(msg, duracao=1000, cor="red"):
    win = tk.Tk()
    win.overrideredirect(True)  # Remove barra de título
    win.configure(bg=cor)

    largura = 1500
    altura = 500
    pos_x = win.winfo_screenwidth() // 2 - largura // 2
    pos_y = win.winfo_screenheight() // 2 - altura // 2
    win.geometry(f"{largura}x{altura}+{pos_x}+{pos_y}")

    label = tk.Label(win, text=msg, fg="black", bg=cor, font=("Arial", 18, "bold"))
    label.pack(expand=True)

    win.after(duracao, win.destroy)  # Fecha sozinho após X milissegundos
    win.mainloop()

# Quantidade de vezes que vai repetir
quantidade = 50
intervalo = 0.1  # segundos entre cada janela

# Mostra as janelas
for _ in range(quantidade):
    mostrar_mensagem("error!!!!", duracao=350, cor="white")
    time.sleep(intervalo)
