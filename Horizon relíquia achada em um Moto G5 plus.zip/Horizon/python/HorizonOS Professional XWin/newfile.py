recursos esperados para a V2

Navegador mais detalhado 

CD pra dados também 

Memory Card para informações temporárias 

aprimoração na UI

[Feito] Definir um nome novo pra UI

[Descontinuado]definição das versões com Vx Build x "não compensa!"

fazer uma versao do disquete sem o class para melhorar a chamada em arquivos que tava dando problema e apps como o editor que tava dando erro

Ocultar o disquete e liberar na versão seguinte

remover recursos inútil

tirar opções que fazem a mesma coisa

adicionar opções pra mudar os usuários e as senha

organizar as funções para chamar cada um separadamente e facilita a chamada por outros arquivos.
 reler o código todo para ver se tem erro porque foi feito pelo ChatGPT.]
 
 adicionar mais comentários para facilitar ler o código.
 
deixar o devmode mais funcional

aprimorar a InfinixUI para todo os apps

[Feito] fazer um módulo "InfinixUI-modules"
[Feito] fazer um módulo "InfinixOS-modules"
[Feito] fazer um módulo "InfinixOS-Apps"

aprimorar o devmode

adicionar o recurso de não apagar tudo só por causa de um input

tirar os recursos inútil da bios

atualizar o help

resolver o bug da barra de carregamento 1

Tentar simular um pequeno terminal Linux para de bugs "ideia temporaria"

Fazer os comando com a lógica de linguagem unica

adicionar a opção de ligar e desligar a rede

adicionar bloqueia no uso de funções do devmode e na bios "principalmente" se o secure boot tiver desativado 

adicionar uma opção para desativar o Devmode 

fazer um editor com língua própria baseado nos módulos usando a base do Horizon editor atual 