import datetime
import tkinter as tk

def mostrar_data_hora():
    agora = datetime.datetime.now()
    texto = agora.strftime("%d/%m/%Y %H:%M:%S")
    label.config(text=texto)

# Criar a janela
janela = tk.Tk()
janela.title("Relógio Simples")
janela.geometry("300x100")

# Texto
label = tk.Label(janela, text="", font=("Arial", 16))
label.pack(pady=20)

# Atualiza a cada segundo
def atualizar():
    mostrar_data_hora()
    janela.after(1000, atualizar)

atualizar()
janela.mainloop()
