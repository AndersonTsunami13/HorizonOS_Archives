import os
import time

# Pergunta quantas janelas quer abrir
quantidade = input("Quantas janelas CMD deseja abrir? (Ex: 5, 10, 20) ")

# Nome do arquivo BAT temporário
arquivo_bat = "simulador_hack.bat"

# Comandos do CMD para parecer um ataque hacker
comandos = f"""
@echo off
mode con: cols=120 lines=40
color 0A
title Acesso Remoto Ativado...

:: Abre várias janelas CMD de acordo com a quantidade escolhida
for /L %%i in (1,1,{quantidade}) do start cmd /c "title Processando... && color 0A && mode con:cols=120 lines=40 && echo Conectando ao servidor... && timeout /t 2 >nul && echo Extraindo senhas... && timeout /t 3 >nul && echo Enviando dados... && timeout /t 3 >nul && exit"

:: Janela principal
cls
echo Conectando ao servidor...
timeout /t 2 /nobreak >nul
echo Acessando banco de dados...
timeout /t 2 /nobreak >nul
echo Extraindo senhas...
timeout /t 2 /nobreak >nul
echo Descriptografando arquivos...
timeout /t 2 /nobreak >nul
echo Coletando logs de atividades...
timeout /t 2 /nobreak >nul
echo Enviando dados para o servidor...
timeout /t 2 /nobreak >nul

echo.
echo ALERTA: O SISTEMA FOI COMPROMETIDO! DESLIGANDO EM 10 SEGUNDOS...
timeout /t 10 /nobreak >nul
exit
"""

# Criar o arquivo BAT
with open(arquivo_bat, "w") as f:
    f.write(comandos)

# Executar o BAT no CMD
os.system(f"start {arquivo_bat}")

# Espera um pouco e apaga o arquivo (opcional)
time.sleep(20)
os.remove(arquivo_bat)
