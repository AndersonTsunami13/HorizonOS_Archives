import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import os

# Funções
def atualizar_relogio():
    agora = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    relogio_label.config(text=f"Agora: {agora}")
    janela.after(1000, atualizar_relogio)

def mostrar_info():
    nome = entrada_nome.get()
    escolha = opcao_var.get()
    opcional = "Sim" if check_var.get() else "Não"
    texto = area_texto.get("1.0", tk.END).strip()

    msg = f"""🔍 Resumo:
    Nome: {nome}
    Opção escolhida: {escolha}
    Ativar extra: {opcional}
    Comentário: {texto}
    """
    messagebox.showinfo("Dados recebidos", msg)

def limpar_tudo():
    entrada_nome.delete(0, tk.END)
    opcao_var.set("Opção 1")
    check_var.set(0)
    area_texto.delete("1.0", tk.END)

def salvar_relatorio():
    nome = entrada_nome.get().strip()
    escolha = opcao_var.get()
    opcional = "Sim" if check_var.get() else "Não"
    comentario = area_texto.get("1.0", tk.END).strip()
    data_hora = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")

    conteudo = (
        f"Relatório gerado em: {data_hora}\n"
        f"Nome: {nome}\n"
        f"Opção escolhida: {escolha}\n"
        f"Ativar função extra: {opcional}\n"
        f"Comentário:\n{comentario}\n"
        "------------------------------\n"
    )

    # Cria pasta de logs se não existir
    if not os.path.exists("relatorios"):
        os.mkdir("relatorios")

    caminho = f"relatorios/relatorio_{data_hora}.txt"
    with open(caminho, "w", encoding="utf-8") as arquivo:
        arquivo.write(conteudo)

    messagebox.showinfo("Relatório Salvo", f"Relatório salvo em:\n{caminho}")

# Janela principal
janela = tk.Tk()
janela.title("Exemplo Completo com Relatório")
janela.geometry("500x550")

# Relógio
relogio_label = tk.Label(janela, text="", font=("Arial", 12), fg="green")
relogio_label.pack(pady=5)
atualizar_relogio()

# Frame principal
frame = tk.Frame(janela)
frame.pack(pady=10)

# Nome
tk.Label(frame, text="Digite seu nome:", font=("Arial", 10)).grid(row=0, column=0, sticky="w")
entrada_nome = tk.Entry(frame, width=30)
entrada_nome.grid(row=0, column=1, padx=10, pady=5)

# Dropdown de opções
tk.Label(frame, text="Escolha uma opção:", font=("Arial", 10)).grid(row=1, column=0, sticky="w")
opcao_var = tk.StringVar(value="Opção 1")
dropdown = tk.OptionMenu(frame, opcao_var, "Opção 1", "Opção 2", "Opção 3")
dropdown.grid(row=1, column=1, padx=10, pady=5, sticky="w")

# Checkbutton
check_var = tk.IntVar()
check = tk.Checkbutton(frame, text="Ativar função extra", variable=check_var)
check.grid(row=2, column=1, pady=5, sticky="w")

# Área de texto
tk.Label(janela, text="Comentário:", font=("Arial", 10)).pack()
area_texto = tk.Text(janela, height=5, width=50)
area_texto.pack(pady=5)

# Botões
botoes_frame = tk.Frame(janela)
botoes_frame.pack(pady=10)

botao_enviar = tk.Button(botoes_frame, text="Enviar", command=mostrar_info, bg="#4CAF50", fg="white", width=12)
botao_enviar.grid(row=0, column=0, padx=5)

botao_limpar = tk.Button(botoes_frame, text="Limpar", command=limpar_tudo, bg="#f44336", fg="white", width=12)
botao_limpar.grid(row=0, column=1, padx=5)

botao_salvar = tk.Button(botoes_frame, text="Salvar Relatório", command=salvar_relatorio, bg="#2196F3", fg="white", width=16)
botao_salvar.grid(row=0, column=2, padx=5)

# Rodapé
tk.Label(janela, text="Feito com Python + Tkinter", font=("Arial", 8), fg="gray").pack(pady=5)

janela.mainloop()
