# info.py

# ===== Sistema de Dados HNDX =====

# marcando início da inicialização do sistema 
inicio_sistema = None 

# ---------- Command ----------
modo_furtivo = False

# ---------- Senhas ----------
senha_correta = "1234"          # Senha padrão do sistema
senha_bios = "BIOSHMT"          # Senha de acesso da BIOS (HMT = Horizon Megatrends)
senha_devmode = "A007DEV"       # Senha para acessar o DevMode (A007 = Agente 007)
senha_showscriptsystem = "HOSIX" 

# ---------- Desenvolvedor ----------
name_DEV = "Anderson Tsunami"        # Nome do desenvolvedor

# ---------- Informações do Sistema ----------
name_system = "HorizonOS Infinix X"
versao_system = "V2. 00- Ghost Edition"             # Número da versão
versaoUI_system = "HorizonUIInfinixX_V2"  # Versão da interface gráfica
bios_version_system = "V10.0"           # Versão da BIOS
name_ui_apps = "InfinixUI-Apps"
version_ui_apps = "V2.0"

# ---------- Controle de Permissões ----------
enable_secure_bios = True        # Permissão de acesso à BIOS
modo_dev = False            # Ativa o DevMode
command_kill = False             # Comando que mata o sistema
console_active = False           # Status do console
Beta = False                   # Modo Beta ativado

# ---------- Arquivo de Dados ----------
ARQUIVO = "dados.json"
LOG_FILE = "LogX.log"

# ---------- Pastas ----------
PASTA_PROJETOS = "projetos"

# ---------- NameTegs do Sistema ----------
# NameTeg padrão do usuário
name_tegs_system = [
    "@systemX",
    "@EliteX",
    "@HorizonOS"
]

# NameTegs para DevMode
name_tegs_system_dev = [
    "@EliteX",
    "@DevModeX"
]

# Assistentes virtuais 
# Facilita para não desenhar várias vezes 
neo = " /\\_/\\\n( o.o )\n > ^ <"
dead = " /      \\\n \\ X  X /\n   ||||" 
#6. D.E.A.D. — sigla misteriosa tipo "Death Execution And Deletion".    

def debugXx():
    print("==== Senhas ====")
    print(f"Senha correta:    {senha_correta}")
    print(f"Senha da BIOS:    {senha_bios}")
    print(f"Senha do DevMode:    {senha_devmode}")
    print(f"senha do comando showscriptsystem: {senha_showscriptsystem}\n")
    
    print("==== Desenvolvedor ====")
    print(f"Dev:    {name_DEV}\n")
    
    print("==== Informações do sistema ====")
    print(f"Nome do sistema:    {name_system}")
    print(f"Versão:    {versao_system}")
    print(f"Versão da UI:    {versaoUI_system}")
    print(f"Versão da BIOS:    {bios_version_system}")
    print(f"Nome da UI dos apps:    {name_ui_apps}")
    print(f"Versão da UI dos apps:    {version_ui_apps}\n")

    print("==== Controle de permissões ====")
    print(f"Enable secure bios:    {enable_segure_bios}")
    print(f"Modo Dev:    {modo_dev}")
    print(f"Comando kill:    {command_kill}")
    print(f"Console ativado:    {console_active}")
    print(f"Recursos beta:    {Beta}\n")

    print("==== Arquivos de dados ====")
    print(f"Arquivo de dados:    {ARQUIVO}")
    print(f"Arquivo de log:    {LOG_FILE}\n")

    print("==== Assistentes ====")
    print(neo)
    print(dead)
    print("\n6. D.E.A.D. — sigla misteriosa tipo (Death Execution And Deletion).")
    
    input()

if __name__ == "__main__":
    debugXx()