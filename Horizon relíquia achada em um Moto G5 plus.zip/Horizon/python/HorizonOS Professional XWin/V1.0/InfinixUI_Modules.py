import sys
import os
import time
from datetime import datetime

from info import *
from font import escrever, limpar, enter

# funcao de hora para o comando tempo
def formatar_tempo(segundos):
    horas = segundos // 3600
    minutos = (segundos % 3600) // 60
    segundos_rest = segundos % 60
    return f"{horas:02d}:{minutos:02d}:{segundos_rest:02d}"

uptime_segundos = int(time.time() == inicio_sistema)

def barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE"):
    """
    tipo: 1 - "barra" ou 2 - "spinner"
    tamanho: tamanho da barra
    duracao: duração do spinner em segundos
    cor/fundo: cores ANSI
    """
    if tipo == 1:
        for i in range(1, tamanho + 1):
            barra = "█" * i
            porcentagem = int((i / tamanho) * 100)
            sys.stdout.write(f"\r{porcentagem}% {barra}")
            sys.stdout.flush()
            time.sleep(duracao / tamanho)

    elif tipo == 2:
        frames = ["\\", "/", "-", "\\"]
        fim = time.time() + duracao
        i = 0
        while time.time() < fim:
            sys.stdout.write(f"\rCarregando Beta... {frames[i % len(frames)]}")
            sys.stdout.flush()
            time.sleep(0.2)
            i += 1
        sys.stdout.write("\rCarregamento concluído!   \n")
    else:
        escrever("Tipo de animação inválido! Escolha 'barra' ou 'spinner'.", "RED")
        
# Animação: bola quicando
quadros = [
    "0       \n        \n        \n        \n        \n        \n        \n        ",
    "  0     \n        \n        \n        \n        \n        \n        \n        ",
    "    0   \n        \n        \n        \n        \n        \n        \n        ",
    "      0 \n        \n        \n        \n        \n        \n        \n        ",
    "        0\n        \n        \n        \n        \n        \n        \n        ",
    "      0 \n        \n        \n        \n        \n        \n        \n        ",
    "    0   \n        \n        \n        \n        \n        \n        \n        ",
    "  0     \n        \n        \n        \n        \n        \n        \n        ",
]

def mostrar_animacao(quadros, fps=1):
    pausa = 1 / fps
    while True:  # loop infinito
        for quadro in quadros:
            limpar()
            print(quadro)
            time.sleep(pausa)
        
def tela_da_morte(CD="Unknown", AA="Unknown", C="Sem detalhes", L="Indefinido", TF="0", erroname = None):
    limpar()
    largura = 80
    escrever("=" * largura, "RED")
    escrever(" " * ((largura - 30)//2) + " !!! HORIZONOS SYSTEM FAILURE !!!", "RED")
    escrever("=" * largura, "RED")
    
    escrever("\n[Aviso!] Um erro fatal foi detectado no sistema.")
    escrever("\n[Aviso!] O sistema foi encerrado para evitar danos.\n")
    
    escrever(f"Código do erro:    {CD}", "YELLOW")
    escrever(f"Arquivo afetado:    {AA}", "YELLOW")
    escrever(f"Comentários:    {C}", "YELLOW")
    escrever(f"Local:    {L}\n", "YELLOW")
    
    enter()
    
    if TF == "0":
        iniciar_terminal()  # função principal do terminal
    else:
        tela_fatal(erroname)

def tela_fatal(erro_texto="Erro desconhecido"):
    limpar()
    largura = 80
    frase = "!!! HORIZONOS SYSTEM FATAL ERROR !!!"
    # Linha de cima inteira vermelha
    escrever(" " * largura, "RED", "normal", "RED")

    # Linha do meio: fundo vermelho em toda a largura, frase centralizada
    meio = frase.center(largura)  # centraliza a frase
    escrever(meio, "WHITE", "normal", "RED")

    # Linha de baixo inteira vermelha
    escrever(" " * largura, "RED", "normal", "RED")
    
    escrever("# Recomenda-se fechar e reabrir o sistema.", "YELLOW")
    escrever("# Se o problema persistir, infelizmente tem problemas no código.", "YELLOW")
    
    escrever("\n[Detalhes do problema]:", "CYAN")
    escrever(erro_texto)

    enter()
    sys.exit()
    
# debug 👇👇👇
    
    # o modo debug e usado caso queira ver se o problema dos logs e no arquivo principal ou no python.
def debug():
    while True:
        limpar()
        escrever("[DEBUG mode]\n", "BLACK", "apagado", "WHITE")
        escrever(">>> O que Você que fazer?", "YELLOW", "destaque")
        escrever("1. Testar a tela da morte")
        escrever("2. Testar a tela de erro fatal")
        escrever("3. Testar as novas barras de carregamento ")
        escrever("4. Sair")
        r = input("> ")
        if r == "1":
            escrever("# os detalhes do problemas e definido em todos os try/except que chama a tela da morte.", "YELLOW")
            enter()
            escrever("você deseja...\n1. definir os detalhes\n2. definir os detalhes padrão (None)")
            r = input("> ")
            if r == "1":
                limpar()
                a = input("Código do erro:")
                b = input("Arquivo afetado:")
                c = input("Comentários:")
                d = input("Local:")
                escrever("Chamar a tela de erro fatal?\n0. não\n1. Sim")
                r = input("> ")
                if r == "1":
                    e = "1"
                else:
                    e = "0"
                f = input("detalhes do erro para a tela de erro fatal:")
                tela_da_morte(a, b, c, d, e, f)
            else:
                tela_da_morte()
        elif r == "2":
            escrever("# o nome do erro e definido na hora de chamar a tela da morte, usando uma biblioteca pra ver aonde e, qual o arquivo e o motivo do erro.", "YELLOW")
            enter()
            limpar()
            escrever("Deseja...\n1. Erro fatal sem nome\n2. Erro fatal com nome diferente")
            r = input("> ")
            if r == "2":
                code = input("Digite um nome de erro diferente:")
                tela_fatal(code)
            else:
                tela_fatal()
        elif r == "3":
            barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE")
            enter()
            barra_carregando(tipo=2,duracao=5, cor="BLACK", fundo="WHITE")
            enter()
        elif r == "4":
            escrever("Saindo...", "YELLOW") 
            sys.exit()
        else:
            escrever("Opção inválida! tente novamente.")
            time.sleep(0.5)
        
if __name__ == "__main__":
    debug()
    
# esse arquivo não tem muitos comentários por ser pequeno e fácil de ler, quem sabe mexer com python não vai ter problemas.

if __name__ == "__main__":
    mostrar_animacao(quadros, fps=2)  # 2 frames por segundo