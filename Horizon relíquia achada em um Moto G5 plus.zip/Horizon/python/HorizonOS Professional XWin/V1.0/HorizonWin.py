# HorizonWin.py

# importações de biblioteca 
import time, system, os
import tkinter as tk
from tkinter import messagebox
from turtle import delay

# importação das pastas
sys.path.append(os.path.join(os.path.dirname(__file__), "AppsWin"))
sys.path.append(os.path.join(os.path.dirname(__file__), "System"))

# importação dos arquivos 
from MeuPc import abrir_meu_pc
from Terminal import abrir_terminal
from Lixeira import abrir_lixeira
from Navegador import abrir_navegador
from config import *

# =============================
# CONFIGURAÇÕES PERSONALIZÁVEIS
# =============================
DISCOS = ["C:/", "D:/", "E:/", "F:/", "G:/"]  # Edite aqui se quiser


# =============================
# Função de inicialização (Tela de Boot)
# =============================
def boot_sequence():
    boot_window = tk.Tk()
    boot_window.configure(bg=TEMA_FUNDO_INI)
    boot_window.attributes("-fullscreen", True)
    boot_window.title(f"Horizon Galaxy Edition One {VERSAO_HORIZON_2}")

    logo = tk.Label(boot_window,
                    text="Horizon Galaxy Edition One",
                    font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_1)),
                    fg=f"{TEMA_TEXTO_1}",
                    bg=f"{TEMA_CONTORNO_INI}")
    logo.pack(pady=200)

    mensagem_1 = tk.Label(boot_window, text=f"Base: {VERSAO_BASE}",
                          font=(f"{FONT_TEXTO}", 10), fg=f"{TEMA_TEXTO_1}", bg=f"{TEMA_CONTORNO_INI}")
    mensagem_1.place(x=10, y=10)

    mensagem_2 = tk.Label(boot_window, text="Inicializando Galaxy Edition One...",
                          font=(f"{FONT_TEXTO}", 10), fg=f"{TEMA_TEXTO_1}", bg=f"{TEMA_CONTORNO_INI}")
    mensagem_2.place(x=10, y=30)

    mensagem_3 = tk.Label(boot_window, text="Isso pode demorar um pouco!",
                          font=(f"{FONT_TEXTO}", 10), fg=f"{TEMA_TEXTO_1}", bg=f"{TEMA_CONTORNO_INI}")
    mensagem_3.place(x=10, y=50)

    mensagem_4 = tk.Label(boot_window, text=f"versao {VERSAO_HORIZON_2}",
                          font=(f"{FONT_TEXTO}", 10), fg=f"{TEMA_TEXTO_1}", bg=f"{TEMA_CONTORNO_INI}")
    mensagem_4.place(x=10, y=70)

    loading_text = tk.Label(boot_window, text=f"{TEXTO_CARREGANDO_INI}", font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_2)), fg=f"{TEMA_TEXTO_1}", bg=f"{TEMA_CONTORNO_INI}")
    loading_text.pack(pady=10)

    progress_bar = tk.Canvas(boot_window, width=900, height=10, bg=f"{TEMA_FUNDO_INI}")
    progress_bar.pack(pady=10)
    progress = progress_bar.create_rectangle(0, 0, 0, 20, fill=f"{TEMA_CARREGANDO}")

    def update_progress():
        def step(i):
            progress_bar.coords(progress, 0, 0, i, 10)
            boot_window.update()

            # Se a barra não chegou ao máximo, chama a função step novamente
            if i < 900:
                boot_window.after((TEMPO_INI), step, i + 1)  # A cada 10ms, chama o step com o próximo valor
            else:
                boot_window.destroy()  # Quando chegar ao fim, fecha a janela
                open_desktop()  # Chama a função da área de trabalho

        step(0)  # Inicia o processo com 0%

    update_progress()
    boot_window.mainloop()


# =============================
# Função da Área de Trabalho
# =============================
def open_desktop():
    janela = tk.Tk()
    janela.title("Horizon Galaxy Edition One {VERSAO_HORIZON_2}")
    janela.attributes("-fullscreen", True)
    janela.configure(bg=f"{TEMA_FUNDO}")

        # =============================
    # 👻 GHOST CLOCK - TOPO ESQUERDO
    # =============================

    import random

    frases = [
        "No frio da noite, será que você está sozinho?",
        "O tempo passa. Você percebe?",
        "Nem toda presença faz barulho.",
        "Você confia no silêncio?",
        "Enquanto você observa, algo observa você."
    ]

    ultima_troca = time.strftime("%M")
    frase_atual = random.choice(frases)

    frame_ghost = tk.Frame(janela, bg=TEMA_FUNDO)
    frame_ghost.place(x=10, y=10)

    ghost_hora = tk.Label(
        frame_ghost,
        text="",
        font=("Consolas", 14),
        fg=TEMA_TEXTO_1,
        bg=TEMA_FUNDO
    )
    ghost_hora.pack(anchor="w")

    ghost_frase = tk.Label(
        frame_ghost,
        text=frase_atual,
        font=("Consolas", 9),
        fg=TEMA_TEXTO_1,
        bg=TEMA_FUNDO,
        wraplength=300,
        justify="left"
    )
    ghost_frase.pack(anchor="w")

    def atualizar_ghost():
        nonlocal ultima_troca, frase_atual

        hora_atual = time.strftime("%H %M %S") if int(time.time()) % 2 == 0 else time.strftime("%H:%M:%S")
        minuto_atual = time.strftime("%M")

        ghost_hora.config(text=f"[ {hora_atual} ]")

        if minuto_atual != ultima_troca:
            frase_atual = random.choice(frases)
            ghost_frase.config(text=frase_atual)
            ultima_troca = minuto_atual

        janela.after(1000, atualizar_ghost)

    atualizar_ghost()

    # ÍCONES
    def icone_abrir_pc():
        abrir_meu_pc()

    def icone_abrir_lixeira():
        abrir_lixeira()

    def icone_abrir_jogos():
        messagebox.showerror("Erro", "algo nao deu certo!")

    def icone_abrir_terminal():
        abrir_terminal()

    def icone_abrir_navegador():
        abrir_navegador()

    # ÍCONES NA TELA
    tk.Label(janela, text="🖥️\nMeu PC", fg=f"{TEMA_ICONE_1}", bg=f"{TEMA_ICONE_2}", font=(f"{FONT_ICONE}", (FONT_ICONE_VALOR)), justify="center",
             cursor="hand2").place(x=30, y=30)
    tk.Label(janela, text="🗑\nLixeira", fg=f"{TEMA_ICONE_1}", bg=f"{TEMA_ICONE_2}", font=(f"{FONT_ICONE}", (FONT_ICONE_VALOR)), justify="center",
             cursor="hand2").place(x=30, y=90)
    tk.Label(janela, text="🕹\nMeus Jogos", fg=f"{TEMA_ICONE_1}", bg=f"{TEMA_ICONE_2}", font=(f"{FONT_ICONE}", (FONT_ICONE_VALOR)), justify="center",
             cursor="hand2").place(x=30, y=150)
    tk.Label(janela, text="👨‍💻\nTerminal", fg=f"{TEMA_ICONE_1}", bg=f"{TEMA_ICONE_2}", font=(f"{FONT_ICONE}", (FONT_ICONE_VALOR)), justify="center",
             cursor="hand2").place(x=30, y=210)
    tk.Label(janela, text="📶\nNavegador", fg=f"{TEMA_ICONE_1}", bg=f"{TEMA_ICONE_2}", font=(f"{FONT_ICONE}", (FONT_ICONE_VALOR)), justify="center",
             cursor="hand2").place(x=30, y=270)

    # Associando funções
    janela.children[list(janela.children)[0]].bind("<Button-1>", lambda e: icone_abrir_pc())
    janela.children[list(janela.children)[1]].bind("<Button-1>", lambda e: icone_abrir_lixeira())
    janela.children[list(janela.children)[2]].bind("<Button-1>", lambda e: icone_abrir_jogos())
    janela.children[list(janela.children)[3]].bind("<Button-1>", lambda e: icone_abrir_terminal())
    janela.children[list(janela.children)[4]].bind("<Button-1>", lambda e: icone_abrir_navegador())

    # Barra de tarefas
    barra = tk.Frame(janela, bg=f"{TEMA_BARRA_DE_TAREFA}", height=35)
    barra.pack(side="bottom", fill="x")

    botao_iniciar = tk.Label(barra, text="⛰ Iniciar", fg=f"{TEMA_ICONE_3}", bg=f"{TEMA_BARRA_DE_TAREFA}", font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_4)), padx=10,
                             cursor="hand2")
    botao_iniciar.pack(side="left")
    botao_iniciar.bind("<Button-1>", lambda e: abrir_menu_iniciar())

    relogio = tk.Label(barra, text="", fg=f"{TEMA_ICONE_4}", bg=f"{TEMA_BARRA_DE_TAREFA}", font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_4)))
    relogio.pack(side="right", padx=10)

    def atualizar_relogio():
        hora = time.strftime("%H:%M:%S")
        relogio.config(text=hora)
        janela.after(1000, atualizar_relogio)

    atualizar_relogio()
    janela.mainloop()

def abrir_menu_iniciar():
    menu = tk.Toplevel()
    menu.title("Iniciar")
    menu.geometry("200x300")
    menu.configure(bg=f"{TEMA_FUNDO}")

    tk.Button(menu, text="Meu PC", bg=f"{TEMA_ICONE_6_1}", fg=f"{TEMA_ICONE_6_2}", font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_3)), command=abrir_meu_pc).pack(pady=10)
    tk.Button(menu, text="Terminal", bg=f"{TEMA_ICONE_6_1}", fg=f"{TEMA_ICONE_6_2}",font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_3)), command=abrir_terminal).pack(pady=10)
    tk.Button(menu, text="Desligar", bg=f"{TEMA_ICONE_7_1}", fg=f"{TEMA_ICONE_7_2}",font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_3)), command=exit).pack(pady=10)
    tk.Button(menu, text="Fechar Menu", bg=f"{TEMA_ICONE_8_1}", fg=f"{TEMA_ICONE_8_2}", font=(f"{FONT_TEXTO}", (FONT_TEXTO_VALOR_3)), command=menu.destroy).pack(pady=10)

# Iniciar o sistema
boot_sequence()
