# verificacao de senha
def validar_senha(senha_digitada):
    return senha_digitada == senha_correta 
    
# tela de login
def login():
    escrever("\n== LOGIN ==", "GREEN", "destaque")
    tentativas = 0
    while True:
        usuario = input("Usuario: ")
        senha = input("Senha: ")
        if validar_senha(senha):
            escrever(f"Acesso concedido! Bem-vindo, {usuario}.", "YELLOW")
            return usuario
        else: 
            tentativas += 1
            escrever("Senha incorreta! Tentativas: {tentativas}", "RED")
            if tentativas == 5:
                escrever("\nSuas tentativas acabaram!", "RED")
                escrever("Seu sistema vai ser reiniciado!" "RED")
                time.sleep(2)
                return
                
# ===== LogX =====

def escrever_log(texto, nivel="0", log=LOG_FILE):
    agora = datetime.now().strftime("%d/%m/%Y %H:%M:%S")  # Timestamp
    niveis = {
        "0": "information",
        "1": "alert",
        "2": "warning",
        "3": "danger",
        "4": "message",
        "5": "error"
    }
    nn = niveis.get(nivel, "information")
    with open(log, "a") as arquivo:
        arquivo.write(f"[HNDX] [{nn}] [{agora}] {texto}\n")

def ler_log(log=LOG_FILE):
    limpar()
    escrever(f"\n>>> Conteúdo de {log}\n", "BLUE", "destaque")
    if not os.path.exists(log):
        escrever("O arquivo de log não existe no pacote ", "RED", "apagado")
        return
    with open(log, "r") as arquivo:
        for linha in arquivo:
            escrever(linha.strip(), "GREEN")
    escrever("\n>>> Fim do log.\n", "BLUE", "destaque")

def limpar_log():
    while True:
        limpar()
        escrever("\n>>> [ Bem-vindo ao setor de limpeza do LogX ]", "WHITE", "destaque")
        escrever("Essa opção foi projetada pra limpar o LogX, por enquanto não pode limpar outros logs.\n", "YELLOW")
        escrever("Escolha uma ação:", "CYAN", "destaque")
        escrever("1. Limpar e voltar\n2. Limpar e reiniciar\n3. Limpar e desligar\n4. Escolher um log personalizado\n5. Sair\n")
        escolha = input(">")
        if escolha == "1":
            with open(LOG_FILE, "w") as arquivo:
                escrever("LogX limpo com sucesso!", "GREEN")
            time.sleep(0.6)
            limpar()
            break
        elif escolha == "2":
            with open(LOG_FILE, "w") as arquivo:
                escrever("LogX limpo com sucesso!", "GREEN")
            time.sleep(0.6)
            escrever("Reiniciando o Horizon...", "YELLOW")
            time.sleep(0.5)
            try:
                iniciar_terminal()  # certifique-se de ter essa função
            except:
                escrever("Não foi possível reiniciar por falta do iniciar terminal().", "RED")
                time.sleep(0.6)
                break
        elif escolha == "3":
            with open(LOG_FILE, "w") as arquivo:
                escrever("LogX Limpo com sucesso!", "GREEN")
            time.sleep(0.6)
            escrever("Desligando o Horizon...", "YELLOW")
            time.sleep(0.5)
            sys.exit()
        elif r == "4": 
            escrever("Função ainda não liberada!", "CYAN")
        elif escolha == "5":
            escrever("Cancelando a ação de limpeza...", "YELLOW")
            time.sleep(0.4)
            break
        else:
            escrever("Opção inválida! tente novamente.", "RED", "destaque")
            time.sleep(0.5)
# ===== Fim LogX =====
                
# ==== bios ====
def bios_sequence():
    limpar()
    escrever("    (⁠◔⁠‿⁠◔⁠) Horizon Megatrends - New Era", "BLUE", "destaque", "BLACK")
    escrever(f"    (⁠ ͡⁠°⁠ ͜⁠ʖ⁠ ͡⁠°⁠) BIOS {bios_version_system}", "BLUE", "destaque", "BLACK")
    escrever("    ಠ⁠_⁠ಠ Copyright (C) 2024-2025\n", "BLUE", "destaque", "BLACK")
    escrever(neo)
    escrever("Deseja entrar no Setup? S ou N", "YELLOW")
    resposta = input("> ")
    if resposta in ["S", "s"]:
        escrever("Entrando no setup...")
        time.sleep(3)
        bios_system_0()
    elif resposta in ["N", "n"]:
        escrever("Certo! Aguarde...\n", "GREEN")
    else:
        escrever("Comando nao reconhecido! tente novamente.", "RED")
        time.sleep(1)
        bios_sequence()
    escrever("> DevMessage:")
    escrever("~" * 50, "GREEN")
    escrever("A bios agora tem suporte a modificacoes direto do sistema", "GREEN")
    escrever("~" * 50, "GREEN")
    escrever("\nInitializing hardware...")
    time.sleep(0.4)
    escrever("Detecting drives...", "GREEN")
    time.sleep(0.5)
    escrever("C: Fixed Disk Drive", "GREEN")
    time.sleep(0.3)
    escrever("D: CD-ROM Drive", "GREEN")
    time.sleep(0.3)
    escrever(f"Memory Test: {RAM_TOTAL}MB OK", "GREEN")
    escrever("Loading Operating System...", "YELLOW")
    barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE")
    time.sleep(0.4)

def beta_painel():
    while True:
        limpar()
        escrever("Bem-vindo ao painel de recursos betas do HorizonOS Night Demon X", "RED")
        escrever("\n    Os recursos sao para fazer testes, se não tiver necessidade não use eles aqui! eles serão liberados assim que possível pro sistema clean.", "YELLOW")
        escrever("\nEscolha o recuso que você deseja usar:", "BLUE")
        escrever("1. Alterar as cores    #Serve para mudar o esquema de cor do sistema.")
        escrever("2. Nova barra de status    #novo estilo da barra de informações.")
        escrever("3. Assistente em fase beta    #o teste de uma IA para o HNDX.")
        r = input(">")
        
        if r == "1":
            time.sleep(1)
            color_test()
        elif r == "2":
            status_win()
        elif r == "3":
            horizon_assistant()
        else:
            escrever("[NEO] Esse comando não e o certo nobre!")
            input("Pressione enter pra continuar...")
            
def bios_system_0():
    limpar()
    escrever("Carregando informações...", "GREEN")
    time.sleep(0.8)
    escrever("Verificando informacoes de seguranca...", "BLUE")
    time.sleep(0.3)
    if enable_segure_bios:
        escrever("Permissao ativada!", "GREEN")
        escrever("Aguarde...")
        time.sleep(0.3)
        bios_system()
    else:
        escrever("\nfuncao indisponivel!", "RED")
 
def console_bios():
    if console_active == "true":
        return 
    elif console_active == "false":
        escrever("Você Não tem o Console ativado!", "RED")
        time.sleep(0.9)
        return
    else:
        escrever("Aguarde")
        time.sleep(0.6)
        tela_da_morte()
    while true:
        limpar()
        r = input(">")
        if r == "Console:EnableBeta":
            beta11 = "true"
            escrever("Recursos Beta ativado!", "GREEN")
            console_bios()
        elif r == "Console:Beta.TestEditor":
            meu_disquete = DisqueteVirtual("HorizonDisk")
            meu_disquete.inserir()
            editor_simples(meu_disquete)
            meu_disquete.ejetar()
        elif r == "Console:Beta.TestMemoryCard":
            escrever("O recuso do Memory Card!", "YELLOW")
            try:
                mc = MemoryCard()
                escrever("Memory card inserido", "GREEN")
            except:
                escrever("Erro ao montar o memory card!", "RED")
                console_bios()
            # Usuários
            mc.adicionar_usuario("Tsunami", "Mestre", "700")
            mc.listar_usuarios()
            mc.remover_usuario("Fulano")
            # Configurações
            mc.set_config("tema", "escuro")
            print(mc.get_config("tema"))
            # Logs
            mc.adicionar_log("Sistema iniciado.", "info")
            mc.listar_logs()
        else:
            escrever("Comando não reconhecido! tente novamente.", "RED")
            input()
     
def terminal_simples():
    usuario = input("Digite seu nome:")
    limpar()
    escrever(f"Bem-vindo, {usuario}, ao Mini HorizonOS Terminal!\n")
    escrever("Comandos disponíveis:")
    escrever("  ls     → listar arquivos")
    escrever("  cd     → mudar de pasta")
    escrever("  mkdir  → criar pasta")
    escrever("  touch  → criar arquivo")
    escrever("  cat    → mostrar arquivo")
    escrever("  exit   → sair do terminal\n")
    diretorio_atual = {"nome": "/", "conteudo": {}}
    path = [diretorio_atual]

    while True:
        cmd = input(f"{usuario}@horizon:{'/'.join([d['nome'] for d in path])}$ ").strip().split()
        if not cmd:
            continue
        if cmd[0] == "exit":
            escrever("Saindo do Mini HorizonOS...")
            break
        elif cmd[0] == "ls":
            atual = path[-1]
            escrever("  ".join(atual["conteudo"].keys()) or "(vazio)")
        elif cmd[0] == "mkdir":
            if len(cmd) < 2:
                escrever("Digite o nome da pasta!")
            else:
                path[-1]["conteudo"][cmd[1]] = {"nome": cmd[1], "conteudo": {}}
                escrever(f"Pasta '{cmd[1]}' criada.")
        elif cmd[0] == "touch":
            if len(cmd) < 2:
                escrever("Digite o nome do arquivo!")
            else:
                path[-1]["conteudo"][cmd[1]] = {"nome": cmd[1], "conteudo": ""}
                escrever(f"Arquivo '{cmd[1]}' criado.")
        elif cmd[0] == "cat":
            if len(cmd) < 2:
                escrever("Digite o nome do arquivo!")
            else:
                arquivo = cmd[1]
                atual = path[-1]["conteudo"]
                if arquivo in atual and isinstance(atual[arquivo], dict):
                    escrever(f"'{arquivo}' é uma pasta, não um arquivo!")
                elif arquivo in atual:
                    escrever(atual[arquivo]["conteudo"])
                else:
                    escrever("Arquivo não encontrado.")
        elif cmd[0] == "cd":
            if len(cmd) < 2:
                escrever("Digite o destino!")
            else:
                destino = cmd[1]
                if destino == "..":
                    if len(path) > 1:
                        path.pop()
                elif destino in path[-1]["conteudo"] and isinstance(path[-1]["conteudo"][destino], dict):
                    path.append(path[-1]["conteudo"][destino])
                else:
                    escrever("Pasta não encontrada.")

def bios_system():
    limpar()
    escrever("/" * 75, "GREEN")
    escrever(f"Horizon Megatrends    BIOS {bios_version_system}    Copyright (C) 2024-2025    BIOS System", "BLUE")
    escrever("/" * 75, "GREEN")
    escrever("\n[System] A BIOS está ligada ao sistema.")
    escrever("\n ~~~ Control Center ~~~")
    escrever("[1] Console")
    escrever("[2] Hora e Data")
    escrever("[3] Informações do Sistema")
    escrever("[4] Terminal Simples")
    escrever("[5] Beta painel")
    escrever("[6] Voltar")
    resposta = input(">")
    if resposta == "1":
        console_bios()
    elif resposta == "2":
        hora = time.strftime(f"%H:%M:%S")
        data = time.strftime(f"%d/%m/%Y")
        uptime_segundos = int(time.time() - inicio_sistema)
        escrever(f"Hora atual: {hora}", "CYAN")
        escrever(f"Data atual: {data}", "CYAN")
        escrever(f"Iniciado às: {time.strftime('%H:%M:%S', time.localtime(inicio_sistema))}", "CYAN")
        escrever(f"Tempo ligado: {formatar_tempo(uptime_segundos)}", "CYAN")
        enter()
        bios_system()
    elif resposta == "3":
        escrever("\nCarregando informações do sistema...", "BLUE")
        time.sleep(0.7)
        escrever(f"Nome do Sistema: {name_system}")
        escrever(f"Versão do Sistema: {versao_system}")
        escrever(f"Versão da UI: {versaoUI_system}")
        escrever(f"Dev: {name_DEV}")
        escrever(f"bios segure: {enable_segure_bios}")
        escrever(f"Modo DEV: {modo_dev}")
        enter()
        bios_system()
    elif resposta == "4":
        terminal_simples()
    elif resposta == "5":
        beta_painel()
    elif resposta == "6":
        bios_sequence()
    else:
        escrever("Comando não reconhecido. tente novamente!")
        enter() 
        bios_system()
        
# ==== boot ====
# simulacao de inicializacao de um sistema
def boot_sequence():
    global inicio_sistema
    inicio_sistema = time.time()
    bios_sequence()
    enter()
    escrever(f"Starting {name_system}...", "RED")
    barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE")
    time.sleep(0.4)
    escrever(f"\n{name_system} - {versao_system}", "GREEN", "destaque") 
    time.sleep(0.4)
    barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE")
    escrever("[OK] Núcleo carregado", "YELLOW")
    barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE")
    escrever("[OK] Interface Terminal pronta")
    barra_carregando(tipo=1,duracao=5, tamanho=50, cor="BLACK", fundo="WHITE")
    escrever("\nDigite 'ajuda' para listar os comandos disponíveis\n", "CYAN")
    escrever("-" * 50)
    escrever("\n\n✓ conheça os novos assistentes:\n")
    time.sleep(0.8)
    escrever(dead, "RED")
    time.sleep(0.2)
    escrever("[D.E.A.D.]: Cuidado é irrelevante. Você já foi deletado.\n", "RED")
    time.sleep(0.5)
    escrever(neo, "CYAN")
    time.sleep(0.2)
    escrever("> [Neo]: Ei, humano, cuidado! Essa IA não tá pra brincadeira...")
    
    
# debug 👇👇👇 

# o modo debug e usado caso queira ver se o problema dos logs e no arquivo principal ou no python.
def debug():
    while True:
        limpar()
        escrever("[DEBUG mode]\n", "BLACK", "apagado", "WHITE")
        escrever(">>> O que Você que fazer?", "YELLOW", "destaque")
        escrever("1. Escrever um log")
        escrever("2. Ler o log")
        escrever("3. Limpar log")
        escrever("4. Sair")
        r = input("> ")
        if r == "1":
            limpar()
            escrever("\n0: information\n1: alert\n2: warning\n3: danger\n4: message\n5: error\n")
            c = input("Escreva o conteúdo: ")
            n = input("Escolha um nível: ")
            try:
                escrever_log(c, n)
                escrever("Log escrito com sucesso!", "GREEN")
                time.sleep(0.5)
                debug()
            except:
                escrever("Não foi possível escreve o log!", "RED")
                time.sleep(1)
        elif r == "2":
            ler_log()
        elif r == "3":
            limpar_log()
        elif r == "4":
            escrever("Saindo...", "YELLOW") 
            sys.exit()
        else:
            escrever("Opção inválida! tente novamente.")
            time.sleep(0.5)
        
if __name__ == "__main__":
    debug()