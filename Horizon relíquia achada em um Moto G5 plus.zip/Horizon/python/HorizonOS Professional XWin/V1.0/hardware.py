# hardware.py

import random, time, os, sys

from font import escrever, limpar, enter

def DisqueteVirtual():
    escrever(">>> O disquete está indisponível!", "RED")
    enter()

class DisqueteVirtual2: # O disquete real foi oculto por causa dos erros! 
    def __init__(self, nome, capacidade_kb=1440):
        """
        nome: nome do disquete (string)
        capacidade_kb: tamanho máximo do disquete em KB (default 1.44MB = 1440KB)
        """
        self.nome = nome
        self.capacidade = capacidade_kb
        self.dados = {}  # aqui ficam os arquivos temporários
        self.inserido = False

    def inserir(self):
        """Insere o disquete e limpa os dados antigos."""
        self.inserido = True
        self.dados = {}
        print(f"[HorizonOS] Disquete '{self.nome}' foi inserido e está pronto para uso.")

    def salvar(self, arquivo, conteudo):
        """Salva um arquivo no disquete (se houver espaço)."""
        if not self.inserido:
            print("[ERRO] Nenhum disquete inserido.")
            return

        tamanho = len(str(conteudo))  # tamanho do conteúdo em caracteres
        if tamanho > self.capacidade:
            print("[ERRO] Arquivo muito grande para o disquete!")
            return

        self.dados[arquivo] = conteudo
        print(f"[HorizonOS] Arquivo '{arquivo}' salvo em '{self.nome}'.")

    def carregar(self, arquivo):
        """Carrega o conteúdo de um arquivo do disquete."""
        if not self.inserido:
            print("[ERRO] Nenhum disquete inserido.")
            return None

        if arquivo not in self.dados:
            print(f"[ERRO] Arquivo '{arquivo}' não encontrado no disquete.")
            return None

        print(f"[HorizonOS] Arquivo '{arquivo}' carregado.")
        return self.dados[arquivo]

    def listar_arquivos(self):
        """Lista os arquivos salvos no disquete."""
        if not self.inserido:
            print("[ERRO] Nenhum disquete inserido.")
            return

        if not self.dados:
            print(f"[HorizonOS] Disquete '{self.nome}' está vazio.")
        else:
            print(f"[HorizonOS] Arquivos no disquete '{self.nome}':")
            for arq in self.dados.keys():
                print("  -", arq)

    def ejetar(self):
        """Ejeta o disquete (e apaga tudo automaticamente)."""
        if not self.inserido:
            print("[ERRO] Nenhum disquete para ejetar.")
            return

        self.inserido = False
        self.dados = {}
        print(f"[HorizonOS] Disquete '{self.nome}' foi ejetado. Dados apagados.")
       
      
# Criar disquete
#print("Ola! vamos configurar seu disquete. insira o nome:")
#namedisk = input(">")
#meu_disquete = DisqueteVirtual(namedisk)

# Inserir
#meu_disquete.inserir()
#print("Disquete inserido")

# Salvar arquivos
#print("insira o nome do arquivo:")
#conteudo1 = input(">")
#print("Insira o conteúdo:")
#conteudo2 = input(">")
#meu_disquete.salvar(conteudo1, conteudo2)
#print("insira o nome do segundo arquivo:")
#conteudo1 = input(">")
#print("Insira o conteúdo:")
#conteudo2 = input(">")
#meu_disquete.salvar(conteudo1, conteudo2)

# Listar arquivos
#input("pressione enter para continuar...")
#meu_disquete.listar_arquivos()

# Carregar arquivo
#input()
#print("Qual arquivo você quer carregar?")
#name = input(">")
#conteudo = meu_disquete.carregar(name)
#print("Conteúdo carregado:", conteudo)

# Ejetar disquete
#input("pressione enter para deletar...")
#meu_disquete.ejetar()

# ------------------------------
# Memória e hardware
RAM_TOTAL = 512  # MB
RAM_USADA = 0
VRAM_TOTAL = 128  # MB
VRAM_USADA = 0
DISCO_TOTAL = 2048  # MB
DISCO_USADO_BASE = random.randint(100, 490)
DISCO_USADO_LOGS = 1
DISCO_USADO = 0
CPU_NAME = "Infiel T1000 Series"
CPU_USO = random.uniform(1.0, 90.0)

rede_active = True
rede_download = random.uniform(10.0, 100.0)
rede_upload = random.uniform(2.0, 50.0)

# ------------------------------
# Funções de hardware
def ram_livre():
    return RAM_TOTAL - RAM_USADA

def vram_livre():
    return VRAM_TOTAL - VRAM_USADA

def disco_livre():
    return DISCO_TOTAL - (DISCO_USADO_BASE + DISCO_USADO_LOGS + DISCO_USADO)

def usar_ram(mb):
    global RAM_USADA
    if ram_livre() >= mb:
        RAM_USADA += mb
        return True
    else:
        print(Fore.RED + "[ERROR] Memória RAM insuficiente!" + Style.RESET_ALL)
        return False

def liberar_ram(mb):
    global RAM_USADA
    RAM_USADA = max(0, RAM_USADA - mb)

def usar_vram(mb):
    global VRAM_USADA
    if vram_livre() >= mb:
        VRAM_USADA += mb
        return True
    else:
        print(Fore.RED + "[ERROR] Memória VRAM insuficiente!" + Style.RESET_ALL)
        return False

def liberar_vram(mb):
    global VRAM_USADA
    VRAM_USADA = max(0, VRAM_USADA - mb)

def usar_disco(mb):
    global DISCO_USADO
    if disco_livre() >= mb:
        DISCO_USADO += mb
        return True
    else:
        print(Fore.RED + "[ERROR] Espaço em disco insuficiente!" + Style.RESET_ALL)
        return False

def liberar_disco(mb):
    global DISCO_USADO
    DISCO_USADO = max(0, DISCO_USADO - mb)

# ------------------------------
# Simulação visual do Night Demon
def simular_hardware():
    escrever("\n=== NIGHT DEMON X - HARDWARE STATUS ===", "MAGENTA")
    
    # CPU
    uso_cpu = random.uniform(1.0, 90.0)
    escrever(f"CPU: {CPU_NAME} | Uso atual: {uso_cpu:.2f}%", "YELLOW")
    
    # RAM
    escrever(f"RAM Total: {RAM_TOTAL} MB | Usada: {RAM_USADA} MB | Livre: {ram_livre()} MB", "CYAN")
    
    # VRAM
    escrever(f"VRAM Total: {VRAM_TOTAL} MB | Usada: {VRAM_USADA} MB | Livre: {vram_livre()} MB", "CYAN")
    
    # Disco
    escrever(f"DISCO Total: {DISCO_TOTAL} MB | Usado: {DISCO_USADO_BASE + DISCO_USADO_LOGS + DISCO_USADO} MB | Livre: {disco_livre()} MB", "GREEN")
    
    # Rede
    if rede_active:
        escrever(f"Rede Ativa | Download: {rede_download:.2f} Mbps | Upload: {rede_upload:.2f} Mbps", "BLUE")
    else:
        escrever("Rede Desconectada | Download: -- | Upload: --", "BLUE")
    
    escrever("======================================\n", "MAGENTA")
    
def debugD():
    # Criar disquete
    escrever("Ola! vamos configurar seu disquete. insira o nome:")
    namedisk = input("> ")
    meu_disquete = DisqueteVirtual(namedisk)

    # Inserir
    escrever("Inserindo o disquete...")
    meu_disquete.inserir()
    print("Disquete inserido")

    limpar()
    escrever("Voce está diante de um debug do hardware, aqui você não pode usar normalmente, isso e no sistema normal!\nno caso você vai tá fazendo um teste.")
    enter()
    
    # Salvar arquivos
    limpar()
    escrever("insira o nome do arquivo:")
    conteudo1 = input("> ")
    escrever("Insira o conteúdo:")
    conteudo2 = input("> ")
    meu_disquete.salvar(conteudo1, conteudo2)
    escrever("insira o nome do segundo arquivo:")
    conteudo1 = input("> ")
    escrever("Insira o conteúdo:")
    conteudo2 = input("> ")
    meu_disquete.salvar(conteudo1, conteudo2)

    # Listar arquivos
    limpar()
    enter()
    meu_disquete.listar_arquivos()

    # Carregar arquivo
    enter()
    escrever("Qual arquivo você quer carregar?")
    name = input("> ")
    conteudo = meu_disquete.carregar(name)
    escrever("Conteúdo carregado:" + conteudo)

    # Ejetar disquete
    enter("Pressione enter para apagar o disquete...")
    meu_disquete.ejetar()
    
def debugH():
    if __name__ == "__main__":
        DISCO_USADO_BASE = random.randint(100, 490)
        CPU_NAME = "Infiel T1000 Series"
        try:
            while True:
                limpar()
                escrever(f"{RAM_TOTAL}MB")
                escrever(f"{RAM_USADA}MB")
                escrever(f"{VRAM_TOTAL}MB")
                escrever(f"{VRAM_USADA}MB")
                escrever(f"{DISCO_TOTAL}MB")
                escrever(f"{DISCO_USADO_BASE}MB")
                escrever(f"{DISCO_USADO_LOGS}MB")
                escrever(f"{DISCO_USADO}MB")
                escrever(f"{CPU_NAME}")
                uso_cpu = random.uniform(1.0, 90.0)
                escrever(f"{uso_cpu:.2f}%")
                time.sleep(0.01)
        except KeyboardInterrupt:
            os.system("cls" if os.name == "nt" else "clear")
            escrever("saindo...")
            time.sleep(2)
            sys.exit()
            
# o modo debug e usado caso queira ver se o problema dos logs e no arquivo principal ou no python.
def debug():
    while True:
        limpar()
        escrever("[DEBUG mode]\n", "BLACK", "apagado", "WHITE")
        escrever(">>> O que Você que fazer?", "YELLOW", "destaque")
        escrever("\nSera adicionado novos recursos aqui em breve...\n", "CYAN", "destaque")
        escrever("1. Testar o disquete")
        escrever("2. Ver os Status do hardware")
        escrever("3. Ver os status do hardware ao vivo (Novo!)")
        escrever("4. Sair")
        r = input("> ")
        if r == "1":
            debugD()
        elif r == "2":
            limpar()
            simular_hardware()
        elif r == "3":
            debugH()
        elif r == "4":
            escrever("Saindo...", "YELLOW") 
            sys.exit()
        else:
            escrever("Opção inválida! tente novamente.")
            time.sleep(0.5)
        
if __name__ == "__main__":
    debug()
    
# esse arquivo não tem muitos comentários por ser pequeno e fácil de ler, quem sabe mexer com python não vai ter problemas.