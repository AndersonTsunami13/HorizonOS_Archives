# font.py — Sistema de fonte do GhostUI

"""
~~~ Estrutura de construção do código ~~~

>>> Importação dos módulos
>>> Função de limpar a tela, apertar enter e input silencioso 
>>> Biblioteca de cores do escrever()
>>> Função de escrever
>>> substituição do print
>>> Debug
"""

import sys, os, time, re, getpass # importações 
from colorama import init, Fore, Back, Style # módulo para as cores

# Inicializa o Colorama
init(autoreset=False, strip=False)

# =======================
# Facilitação de escrita
# =======================   
def limpar(): # para limpar a tela
    os.system("cls" if os.name == "nt" else "clear") 
    
def enter(name = "Pressione enter para continuar..."): # aperta enter para continuar 
    input(Fore.CYAN + Style.BRIGHT + name)
    
def input_silencioso(prompt="Digite: "): # escrita oculta
    return getpass.getpass(prompt)

# =======================
# Texto (Fore)
# =======================
TEXTOS = {
    "BLACK": Fore.BLACK, # Preto
    "RED": Fore.RED, # Vermelho 
    "GREEN": Fore.GREEN, # Verde
    "YELLOW": Fore.YELLOW, # Amarelo
    "BLUE": Fore.BLUE, # Azul
    "MAGENTA": Fore.MAGENTA, # Rosa
    "CYAN": Fore.CYAN, # Azul claro
    "WHITE": Fore.WHITE # Branco
}

# =======================
# Fundo (Back)
# =======================
FUNDOS = {
    "BLACK": Back.BLACK, # Preto
    "RED": Back.RED, # Vermelho
    "GREEN": Back.GREEN, # Verde
    "YELLOW": Back.YELLOW, # Amarelo
    "BLUE": Back.BLUE, # Azul 
    "MAGENTA": Back.MAGENTA, # Rosa
    "CYAN": Back.CYAN, # Azul claro
    "WHITE": Back.WHITE # Branco
}

# =======================
# Estilos (Style)
# =======================
ESTILOS = {
    "normal": Style.NORMAL, # Texto normal
    "destaque": Style.BRIGHT, # Texto em negrito "destacado"
    "apagado": Style.DIM, # Texto apagado "podendo ser usado para destaques mais simples..."
    "reset": Style.RESET_ALL # resetar tudo no final "isso é usado só no escrever!"
}

# =======================
# Função única
# =======================
v_cor = "WHITE"
v_estilo = "normal"
v_fundo = "BLACK"
v_velocidade = 0.05 # As próprias variáveis fala o nome*

# caso você realmente queira, e só você ler que você entende essa lógica, não compensa explicar!
def escrever(texto, cor=v_cor, estilo=v_estilo, fundo=v_fundo, velocidade=v_velocidade, pular_linha=True):
    """Escreve texto com cor, fundo, estilo e velocidade (efeito digitando)."""
    mensagem = f"{ESTILOS.get(estilo, Style.NORMAL)}{FUNDOS.get(fundo, Back.BLACK)}{TEXTOS.get(cor, Fore.WHITE)}{texto}{Style.RESET_ALL}"

    partes = re.split(r'(\x1b\[[0-9;]*m)', mensagem)  # separa ANSI
    for p in partes:
        if re.match(r'\x1b\[[0-9;]*m', p):  # se for código ANSI
            sys.stdout.write(p)
            sys.stdout.flush()
        else:
            for c in p:
                sys.stdout.write(c)
                sys.stdout.flush()
                if velocidade > 0:
                    time.sleep(velocidade)
    if pular_linha:
        sys.stdout.write("\n")
        sys.stdout.flush()              

# =======================
# Sobrescreve print global
# =======================
print_original = print
def print(*args, **kwargs):
    texto = " ".join(str(a) for a in args)
    escrever(texto, velocidade=kwargs.get("velocidade", 0.10))

# =======================
# Teste rápido
# =======================
def teste_cores():
    escrever("Preto", "BLACK", "normal", "WHITE")
    escrever("Vermelho", "RED")
    escrever("Verde", "GREEN")
    escrever("Amarelo", "YELLOW")
    escrever("Azul", "BLUE")
    escrever("Magenta", "MAGENTA")
    escrever("Ciano", "CYAN")
    escrever("Branco", "WHITE")
    escrever("Negrito + Azul", "BLUE", "destaque", "BLACK", velocidade=0.01)
    enter()
    
    escrever("HORIZON SYSTEM X LOADING...", cor="CYAN", estilo="destaque", velocidade=0.03)
    escrever("Erro crítico detectado!", cor="RED", estilo="destaque", fundo="BLACK", velocidade=0.01)
    escrever("       √•|™[]√√35", "CYAN", "destaque", "BLACK")

if __name__ == "__main__":
    teste_cores()
    
"""
from font import escrever

escrever("HORIZON SYSTEM X LOADING...", cor="CYAN", estilo="destaque", velocidade=0.03)
escrever("Erro crítico detectado!", cor="RED", estilo="destaque", fundo="BLACK", velocidade=0.01)
escrever("", "CYAN", "destaque", "BLACK")

"""