# HorizonOS.py
# HorizonOS Infinix X 😈
# V2.00 - Ultimate Version 💀
# construído por Anderson Tsunami 
# Analise para estabilidade do simulador por ChatGPT 

# Não se preocupe, o código está bem comentado, então se você está autorizado a modificar, pode mete a mão da massa!
# Outras informações pode está no meio do código para não deixar tudo aqui.

# Melhor exagerar no comentário agora, do que chorar no futuro tentando entender 
# por que raios eu fiz isso...  
# "Pagar 1 hoje é melhor do que pagar 2 amanhã." – Hacker filósofo 🕶️

# > 🕶️ Meu nobre, não se preocupe, esse código e o primeiro a ser totalmente otimizado "👀 tirando a parte dos comentários" mas ainda está com a vibe completa.
# > 😏🔥 o código também foi totalmente refeito reorganizando tudo da úlima edição do Horizon "Horizon Night Demon X 😈.
# > Uma das melhores coisas feita nesse sistema foi nomear como "HorizonOS Infinix X (HOSIX)", Perfeitamente satisfatório de se falar! ☠️🔫😁
# o Infinix X ainda vai continuar carregando o emoji do diabo como sibulo de "Demon" da edição anterior.

# O mais novo e único HorizonOS Infinix X tem algumas organizações que não existe em outras edições anteriores, afinal esse e o primeiro Horizon a possui uma organização única nas pastas.

# Porém pode acontecer alguns bugs raros por um simples motivo: o Infinix e a evolução do código do Horizon Night Demon X, por isso pode acabar ficando algum erro como erro de escrita "esse e o mais resolvido!".

# > Importações dos modulos
from datetime import datetime
import time, os, sys, re, random, getpass

# > Importações das pastas
sys.path.append(os.path.join(os.path.dirname(__file__), "Modules")) 
sys.path.append(os.path.join(os.path.dirname(__file__), "System")) 

# > Importação dos arquivos 
from info import *
from hardware import *
from font import *
from devmode import*
from InfinixUI_Modules import *
from InfinixOS_Modules import *
from InfinixApps_Modules import *
        
def f_mostrar_ajuda():
    escrever("\nComandos disponíveis:", "CYAN", "destaque")
    escrever("[ Sistema ]", "GREEN")
    escrever("- ajuda        _ Mostrar está lista.")
    escrever("- sobre        _ Mostrar está lista.")
    escrever("- sobre       → Informações do sistema")
    escrever("- tempo       → Mostra hora atual + tempo ligado")
    escrever("- processos   → Simula processos em execução")
    escrever("- limpar      → Limpa a tela (fake)")
    escrever("- senha       → Alterar senha do sistema")
    escrever("- reiniciar   → Reinicia o sistema")
    escrever("- desligar    → Encerra o sistema")
    escrever("- terminalui  → Detalhes da interface atual")
    escrever("- creditos    → Mostra quem desenvolveu")
    escrever("- sugestao    → Envia sugestão fictícia")
    escrever("- config      → Menu de configurações")
    escrever("- historico")
    escrever("- limpar historico")
    escrever("- hardware")
    escrever("- /kill")
    escrever("[Programas]", "YELLOW", "destaque")
    escrever("- meu_pc      → Simula acesso ao disco")
    escrever("- navegador   → Simula navegador fictício")
    escrever("- matrix      → Efeito hacker verde matrix\n")
    escrever("/n===[DEV]===", "YELLOW", "destaque")
    escrever("| >enable devmode")
    escrever("| >status devmode")
    escrever("| >devmode")
    escrever("| > showscriptsystem")
    escrever("# Esta em desenvolvimento.\nAlguns comandos não são mostrados aqui para maior segurança ರ⁠_⁠ರ... Mas você pode acessar pelo modo Dev ou procurando no código (Um pouco arriscado!)")
  
# Funções de comando 
# As funções de comandos sempre vai ter f- para separar a organização.
def f_meu_pc():
    escrever("[Discos disponíveis:]", "GREEN", "destaque")
    escrever("- C:/ (Sistema)")
    escrever("- D:/ (Arquivos)")
    escrever("- E:/ (Backup)")
    escrever("(Sistema de arquivos Beta!)", "RED")

def f_historico():
    escrever("# Talvez se o log estiver grande, pode demorar um pouco pra terminar!", "YELLOW", "destaque")
    escrever("# Na próxima atualização será adicionado o Ctrl+C pra ter um sistema de segurança simples, mas que ajuda.", "YELLOW", "destaque")
    enter()
    limpar()
    escrever("Histórico de comandos:", "YELLOW", "destaque")
    with open("log3.txt", "r") as arquivo:
        conteudo = arquivo.read()
        escrever("\nConteúdo de log3.txt:", "BLUE", "destaque")
        escrever(conteudo) 
      
def f_tempo():
    hora = time.strftime("%H:%M:%S")
    data = time.strftime("%d/%m/%Y")
    uptime_segundos = int(time.time() - inicio_sistema)
    escrever("Hora atual: {hora}", "CYAN")
    escrever("Data atual: {data}", "CYAN")
    escrever("Iniciado às: {time.strftime('%H:%M:%S', time.localtime(inicio_sistema))}", "CYAN")
    escrever("Tempo ligado: {formatar_tempo(uptime_segundos)}", "CYAN")
    
def f_processos():
    escrever("processos em execução...", "GREEN")
    time.sleep(1)
    escrever("- kernel.sys  | em execução")
    escrever("- terminal.py | aguardando entrada")
    escrever("- 007.exe     | finalizado")
    
def f_alterar_senha():
    limpar()
    escrever("Por enquanto não está disponível...")
    enter()
    
def f_sobre():
    escrever("===== Sobre =====", "MAGENTA", "destaque")
    escrever("- Nome do sistema: {name_system}")
    escrever("- versão do sistema: {versao_system}")
    escrever("Versão da interface: {versaoUI_system}")
    escrever("Versão da BIOS: {bios_version_system}")
    escrever("- Desenvolvido por: {name_DEV}")
    escrever("feito usando o ChatGPT")

def f_terminalui():
    escrever("Interface atual: {versaoUI_system}", "GREEN")
    
def f_creditos():
    escrever("Desenvolvido por {name_DEV} usando Python.")
    
def f_config():
    escrever("O menu de configurações ainda está em desenvolvimento...", "YELLOW")
    
def f_showscriptsystem():
    limpar()
    escrever("Digite a senha:", "YELLOW", "destaque")
    resposta = input(">")
    if resposta == senha_showscriptsystem:
        escrever("Certo meu nobre, você será transferido agora!", "GREEN")
        time.sleep(0.5)
        mostrar_codigo_fonte()
    else:
        escrever("Aguarde...\n", "YELLOW")
        time.sleep(4)
        escrever("=" * 50, "RED")
        escrever("VOCÊ QUE OLHAR O CODIGO FONTE E NEM SABE A SENHA?!?!?!", "RED")
        escrever("=" * 50, "RED")
        time.sleep(3)
        iniciar_terminal()
         
def f_kill():
    command_kill = "true"
    escrever(dead, "RED")
    escrever("[D.E.A.D.]: Cuidado é irrelevante. Você já foi deletado.", "RED") 
        
def f_idiot():
    escrever("Você e um idiota!", "GREEN")
    command_kill = "true"
     
def f_curiosidade():
    escrever("Você e o mais no idiota. Obrigado pela atenção!", "YELLOW")
     
def f_zoeira():
    escrever("( ͡⁠°⁠ ͜⁠ʖ⁠ ͡⁠°⁠) Hum...", "MAGENTA")
      
def f_reiniciar():
    escrever("Reiniciando sistema...", "YELLOW")
    time.sleep(1.5)
    iniciar_terminal()
       
def f_desligar():
    print(Fore.GREEN + "Desligando... até a próxima!")
    escrever_log("Sistema Desligado.", "log3.txt")
    sys.exit()
    
def f_sugestao():
     sugestao = input("Digite sua sugestão: ")
     print(Fore.GREEN + "Obrigado pela sugestão! (ela será ignorada na versão beta 😅)")
     time.sleep(0.5)
     print("=" * 20)
     print("Deseja salvar a sugestão na memoria? S ou N")
     resposta = input(">")
     if resposta in ["S", "s"]:
        print("Ok! Estamos salvando a sua sugestao na memoria...")
        escrever_log("=" * 15, "log3.txt")
        escrever_log(f"Sugestao do{usuario}", "log3.txt")
        escrever_log(f"{sugestao}", "log3.txt")
        escrever_log("=" * 15, "log3.txt")
        escrever_lento(Fore.GREEN + "Sugestao salva com sucesso!")
        print("=" * 20)
        time.sleep(0.3)
     elif resposta in ["N", "n"]:
        print(Fore.GREEN + "Certo! Pode seguir em frente.")
        time.sleep(0.3)
     else:
        print(Fore.RED + "Comando nao reconhecido! tente novamente.")
        time.sleep(0.3)
        return resposta
        
# efeito matrix brabo
def f_efeito_matrix():
    usar_vram(8)
    chars = "01"
    try:
        for _ in range(40):
            linha = "".join(random.choice(chars) for _ in range(120))
            print(Fore.GREEN + linha)
            time.sleep(0.05)
    except KeyboardInterrupt:
        pass
        
def f_efeito_matrix2():
    usar_vram(8)
    chars = "01"
    try:
        while True:
            linha = "".join(random.choice(chars) for _ in range(120))
            print(Fore.GREEN + linha)
            time.sleep(0.03)
    except KeyboardInterrupt:
        print("\n[Efeito Matrix interrompido]")
    efeito_matrix()
    
def f_alterar_senha():
    global senha_correta
    antiga = input("Digite a senha atual: ")
    if validar_senha(antiga):
        nova = input("Digite a nova senha: ")
        senha_correta = nova
        print(Fore.GREEN + "Senha alterada com sucesso!")
    else:
        print(Fore.RED + "Senha atual incorreta! Operação cancelada.")
        
def f_ativar_furtivo():
    global modo_furtivo
    modo_furtivo = not modo_furtivo
    if modo_furtivo:
        esconder_tela()
    else:
        escrever(">> MODO FURTIVO DESATIVADO <<", Fore.GREEN)

def esconder_tela():
    global modo_furtivo
    while modo_furtivo:
        limpar()
        escrever(">> MODO FURTIVO <<".center(60), Fore.YELLOW)
        escrever("(Digite 0 para desativar)".center(60), Fore.YELLOW)
        r = input_silencioso("> ")
        if r.strip() == "0":
            modo_furtivo = False
            escrever(">> MODO FURTIVO DESATIVADO <<", Fore.GREEN)
            time.sleep(1)
            return
        
# Dicionário de comandos
comandos = {
    "ajuda": f_mostrar_ajuda,
    "meu_pc": f_meu_pc,
    "limpar historico": limpar_log,
    "navegador": navegador,
    "limpar": limpar,
    "tempo": f_tempo,
    "processos": f_processos,
    "senha": f_alterar_senha,
    "sobre": f_sobre,
    "hardware": simular_hardware,
    "terminal UI": f_terminalui,
    "créditos": f_creditos,
    "sugestao": f_sugestao,
    "config": f_config,
    "matrix": f_efeito_matrix,
    "status devmode": status_devmode,
    "enable devmode": enable_devmode,
    "devmode": devmode,
    "showscriptsystem": f_showscriptsystem,
    "/kill": f_kill,
    ("/nazismo", "/Hitler"): tela_da_morte, # Comando por zoeira, sem referência histórica. Só dispara a tela da morte.
    ("/you are a idiot", "/idiota", "/idiot"): f_idiot,
    ("curiosidades", "curiosidade"): f_curiosidade,
    "zoeira": f_zoeira,
    "reiniciar": f_reiniciar,
    ("desligar", "sair"): f_desligar,
    "171": "fraude é ilusão, crime organizado é estiloso.",
    "007": "um agente secreto é igual uma sombra, ninguém vê.",
    "666": "o caos alimenta o demônio a noite.",
    "911": "por que ligar para emergência? O demônio só te observa a noite.",
    "1999": "se o bug do milênio nunca fosse resolvido, a escuridão reinaria até hoje.",
    "404": "A resposta se perdeu no caminho da noite.",
    "1337": "quem domina o código, domina tudo.",
    "777": "se preocupar é desnecessário, a vitória é silenciosa.",
    "999": "a noite é o melhor momento pra despertar o monstro interior.",
    "matrix": f_efeito_matrix,
    "matrix2": f_efeito_matrix2,
    "sugestao": f_sugestao,
    "senha": f_alterar_senha,
    "furtivo": f_ativar_furtivo,
    "animação": mostrar_animacao
}

# aonde a magia acontece
def iniciar_terminal():
    global usuario
    limpar()
    usar_ram(13)
    name_teg = random.choice(name_tegs_system)
    boot_sequence()
    if command_kill == "true":
        tela_da_morte()
    escrever("\nO Modo Dev ja esta disponivel!", "GREEN")
    escrever("Digite: (devmode) para entrar.\n", "GREEN")
    usuario = login()
    while True:
         try:
             comando = input(Fore.CYAN + f"{usuario}{name_teg}> ").strip().lower()
             if comando:           
                 usar_ram(1)
                 escrever_log(f"comando: {cmd} Inserido.", "log3.txt")
                 if cmd in comandos:
                    comandos[cmd]()  # chama a função correspondente
             else:
                 escrever("Comando desconhecido: '{cmd}' (digite 'ajuda')", "RED", "destaque")
         except KeyboardInterrupt:
             escrever("\nSistema interrompido pelo usuário.", "RED")
             break
  
# Corrigindo o nome do módulo principal
if __name__ == "__main__":
    try:
        escrever("[DEBUG] Sistema iniciando...")
        iniciar_terminal()
    except Exception as e:
        escrever("#" * 20)
        escrever("[ERRO DETECTADO]")
        escrever(e)
        escrever("#" * 20)
        ErrorMessage = e
        import traceback
        erro_completo = traceback.format_exc()  # pega tudo: arquivo, linha, mensagem
        time.sleep(2)
        tela_da_morte("Starting_Horizon_System", "HorizonOS.py", f"O erro aconteceu no boot do terminal, o erro mais comum e o código ou bugs desconhecidos. ({ErrorMessage})", "inciar_terminal", "1", erro_completo)
    
# Tenha respeito pelo código! grande parte do desenvolvimento foi feito entre 0h00 as 5h00 da madrugada!

# powered by Horizon Universe.