import os
import time

from font import *
from info import *

# Garantir que a pasta existe
if not os.path.exists(PASTA_PROJETOS):
    os.makedirs(PASTA_PROJETOS)

def editor():
    limpar()
    escrever("\n=== Editor ===", "CYAN")
    nome_arquivo = input("Nome do arquivo (ex: jogo.py): ")
    caminho = os.path.join(PASTA_PROJETOS, nome_arquivo)

    escrever("Escreva seu código. Digite '::salvar' em uma nova linha para finalizar.", "YELLOW")
    linhas = []
    while True:
        linha = input()
        if linha.strip() == "::salvar":
            break
        linhas.append(linha)
    
    with open(caminho, "w") as f:
        f.write("\n".join(linhas))
    escrever(f"Arquivo salvo em {caminho}\n", "GREEN")

def hub():
    while True:
        limpar()
        arquivos = os.listdir(PASTA_PROJETOS)
        limpar()
        escrever("=== Hub de Projetos ===", "MAGENTA")
        if not arquivos:
            escrever("Nenhum projeto encontrado.", "RED")
        else:
            for i, arq in enumerate(arquivos):
                escrever(f"{i+1} - {arq}", "CYAN")

        escrever("\nOpções: [E]ditar, [R]odar, [D]eletar, [S]air", "YELLOW")
        escolha = input("Escolha: ").lower()

        if escolha == "e":
            editor()
        elif escolha == "r":
            idx = int(input("Número do arquivo para rodar: ")) - 1
            if 0 <= idx < len(arquivos):
                caminho = os.path.join(PASTA_PROJETOS, arquivos[idx])
                escrever(f"Rodando {arquivos[idx]}...\n", "GREEN")
                os.system(f"python \"{caminho}\"")
            else:
                escrever("Arquivo inválido!", "RED")
        elif escolha == "d":
            idx = int(input("Número do arquivo para deletar: ")) - 1
            if 0 <= idx < len(arquivos):
                caminho = os.path.join(PASTA_PROJETOS, arquivos[idx])
                os.remove(caminho)
                escrever(f"{arquivos[idx]} deletado!", "RED")
            else:
                escrever("Arquivo inválido!", "RED")
        elif escolha == "s":
            escrever("Saindo do Hub...", "GREEN")
            break
        else:
            escrever("Opção inválida!", "RED")
            
def editor_simples(disqueteC):
    DisqueteVirtual(namedisk="namedisk")
    disquete = disqueteC 
    if not disquete.inserido:
        escrever("[HorizonEditor] Nenhum disquete inserido. Insira um disquete antes de abrir o editor.")
        return

    escrever("[HorizonEditor] Editor iniciado. Comandos disponíveis: edit <arquivo>, load <arquivo>, save <arquivo>, list, exit")

    arquivos_abertos = {}  # mantém conteúdo editado temporariamente

    while True:
        comando_raw = input("HorizonEditor> ").strip()
        if not comando_raw:
            continue

        partes = comando_raw.split(maxsplit=1)
        comando = partes[0].lower()
        argumento = partes[1] if len(partes) > 1 else None

        if comando == "edit":
            if not argumento:
                escrever("[HorizonEditor] Use: edit <nome_arquivo>")
                continue

            nome_arquivo = argumento
            conteudo_atual = arquivos_abertos.get(nome_arquivo) or disquete.carregar(nome_arquivo) or ""
            escrever(f"[HorizonEditor] Editando '{nome_arquivo}'. Digite o conteúdo. Linha vazia para finalizar.")

            if conteudo_atual:
                escrever(f"--- Conteúdo atual ---\n{conteudo_atual}\n--- Fim do conteúdo atual ---")
                linhas = conteudo_atual.split("\n")
            else:
                linhas = []

            while True:
                linha = input()
                if linha == "":
                    break
                linhas.append(linha)

            arquivos_abertos[nome_arquivo] = "\n".join(linhas)
            escrever(f"[HorizonEditor] '{nome_arquivo}' pronto para salvar. Use 'save {nome_arquivo}'.")

        elif comando == "load":
            if not argumento:
                escrever("[HorizonEditor] Use: load <nome_arquivo>")
                continue
            nome_arquivo = argumento
            conteudo = disquete.carregar(nome_arquivo)
            if conteudo is not None:
                escrever(f"[HorizonEditor] Conteúdo de '{nome_arquivo}':\n{conteudo}")

        elif comando == "save":
            if not argumento:
                escrever("[HorizonEditor] Use: save <nome_arquivo>")
                continue
            nome_arquivo = argumento
            if nome_arquivo not in arquivos_abertos:
                escrever(f"[HorizonEditor] Nenhuma edição encontrada para '{nome_arquivo}'. Use 'edit {nome_arquivo}' primeiro.")
                continue
            disquete.salvar(nome_arquivo, arquivos_abertos[nome_arquivo])
            escrever(f"[HorizonEditor] '{nome_arquivo}' salvo com sucesso.")

        elif comando == "list":
            disquete.listar_arquivos()

        elif comando == "exit":
            escrever("[HorizonEditor] Saindo do editor…")
            break

        else:
            escrever("[HorizonEditor] Comando desconhecido. Use: edit <arquivo>, load <arquivo>, save <arquivo>, list, exit")
            
# Dicionário de perguntas e respostas
respostas = {
    "como trocar a cor da fonte": "Crie um dicionário de cores e use Fore do Colorama, por exemplo: CORES = {'alerta': Fore.RED, 'seguro': Fore.GREEN}. Depois use print(CORES['alerta'] + 'Mensagem' + Style.RESET_ALL).",
    "como limpar os logs": "Use a função escrever_log('texto', 'nivel') para registrar ou limpar logs.",
    "como ver o status da ram": "Use a função simular_hardware() para ver RAM, VRAM, disco e CPU.",
    "como reiniciar o sistema": "Use iniciar_terminal() para reiniciar o terminal do HorizonOS."
}

# Loop de interação
def horizon_assistant():
    escrever("HorizonAssistant 🕶️ pronto para te ajudar!", "MAGENTA")
    while True:
        pergunta = input(Fore.BLUE + "Pergunta > " + Style.RESET_ALL).lower().strip()
        if pergunta in ["sair", "exit", "quit"]:
            escrever("Assistente encerrado. Até mais!", "CYAN")
            break
        resposta = respostas.get(pergunta, "Desculpa, ainda não sei responder isso. Mas tô aprendendo!")
        escrever(resposta, "YELLOW")
        
# ==== Navegador ====
historico = []

paginas = {
    "horizon.net": "Bem-vindo ao HorizonNet!\n1. Notícias\n2. Jogos\n3. Sobre",
    "horizon.net/noticias": "Últimas notícias:\n- Sistema X Ultra lançado!\n- Bugs resolvidos!",
    "horizon.net/jogos": "Jogos disponíveis:\n- Horizon Tetris\n- Ping Pong Mobile\n- Hackeando o Sistema",
    "horizon.net/sobre": "HorizonNet: navegador textual do HorizonOS.\nPara estudos e diversão."
}

def barra_carregamento():
    for i in range(1, 21):
        print(f"\rCarregando: [{'='*i}{' '*(20-i)}] {i*5}%", end="")
        time.sleep(0.03)
    print()

def abrir_pagina(url):
    barra_carregamento()
    if url in paginas:
        historico.append(url)
        print("\n" + paginas[url])
        if url == "horizon.net":
            escolha = input("Escolha um número> ").strip()
            if escolha == "1":
                abrir_pagina("horizon.net/noticias")
            elif escolha == "2":
                abrir_pagina("horizon.net/jogos")
            elif escolha == "3":
                abrir_pagina("horizon.net/sobre")
            else:
                print("Opção inválida!")
    else:
        print("\n404 Not Found!")

def navegador():
    while True:
        print("\n=== HorizonNet ===")
        print("Digite 'sair' para fechar o navegador.")
        url = input("URL> ").strip()
        if url.lower() == "sair":
            break
        abrir_pagina(url)
    print("Fechando HorizonNet...")
    
    inicio_sistema = None # marcando início da inicialização do sistema 
   
# -------------------------
# Minerador (simulação simples)
# -------------------------
def salvar_saldo(saldo, arquivo="mineracao.txt"):
    try:
        with open(arquivo, "w") as f:
            f.write(f"{saldo:.4f}")
    except Exception:
        pass

def carregar_saldo(arquivo="mineracao.txt"):
    try:
        if os.path.exists(arquivo):
            with open(arquivo, "r") as f:
                return float(f.read())
    except Exception:
        pass
    return 0.0

def mostrar_barrinha(porcentagem, largura=24):
    preenchido = int(porcentagem * largura)
    vazio = largura - preenchido
    return "[" + "#" * preenchido + "-" * vazio + "]"

def minerar_simulado():
    saldo = carregar_saldo()
    incremento = 0.0004
    delay = 0.5
    try:
        escrever("Minerador simulado iniciado! Ctrl+C para pausar.", Fore.YELLOW)
        passo = 0
        while True:
            saldo += incremento
            passo += 1
            porcentagem = (passo % 50) / 50
            barra = mostrar_barrinha(porcentagem)
            sys.stdout.write(f"\rMinerando... {barra} Saldo: {saldo:.4f}")
            sys.stdout.flush()
            incremento += 0.00005
            time.sleep(delay)
    except KeyboardInterrupt:
        print("\n")
        salvar_saldo(saldo)
        escrever(f"Saldo salvo: {saldo:.4f}", Fore.GREEN)
        if input("Deseja resgatar moedas? (s/n): ").strip().lower() == "s":
            escrever(f"Moedas resgatadas: {saldo:.4f}", Fore.GREEN)
            salvar_saldo(0.0) 

# Debug 👇👇👇

if __name__ == "__main__":
    while True:
        limpar()
        escrever("~" * 35, "YELLOW")
        escrever(">>> Horizon: Editor & Hub", "YELLOW")
        escrever("~" * 35, "YELLOW")
        escrever(f"{name_ui_apps} - {version_ui_apps}", "BLUE", "destaque")
        escrever("\n[1] Abrir Editor")
        escrever("[2] Abrir Hub de Projetos")
        escrever("[3] Sair")
        opc = input("> ")
        if opc == "1":
            editor()
        elif opc == "2":
            hub()
        elif opc == "3":
            escrever("Fechando Editor...", "GREEN")
            break
        else:
            escrever("Opção inválida!", "RED")
            
def debug2():
    escrever("Modo Debug iniciado!", "RED", "destaque", velocidade=0.1)
    enter()
    while True:
        limpar()
    
        escrever("~" * 35, "GREEN")
        escrever("           ---Modo debug ", "GREEN")
        escrever("~" * 35, "GREEN")
        escrever(f"{name_ui_apps} - {version_ui_apps}", "BLUE", "destaque")
    
        escrever(f"\n• Escolha uma ação:")
        escrever("1. Criar um disquete (para o editor).")
        escrever("2. Inserir o disquete (para o editor).")
        escrever("3. Salvar arquivos (para o editor).")
        escrever("4. Mostrar arquivos (para o editor).")
        escrever("5. Abrir arquivos (para o editor).")
        escrever("6. Ejetar o disquete (para o editor).")
        escrever("# O disquete não é desse arquivo, o disquete e importado do (hardware) para ser usado no editor.\n")
        escrever("7. Abrir o Horizon editor.")
        escrever("8. Abrir o Horizon Assistant.")
        escrever("9. Abrir o navegador.")
        escrever("10. sair.")
        
        while True:
            rr = input("\n>")
        
            if rr == "1":
                namedisk = input("insira o nome do disquete> ")
                meu_disquete = DisqueteVirtual(namedisk)
                enter()
            elif rr == "2":
                meu_disquete.inserir()
                enter()
            elif rr == "3":
                conteudo1 = input("Insira o nome do arquivo> ")
                conteudo2 = input("Insira o conteudo> ")
                meu_disquete.salvar(conteudo1, conteudo2)
                enter()
            elif rr == "4":
                meu_disquete.listar_arquivos()
                enter()
            elif rr == "5":
                name = input("Qual arquivo você quer carregar?> ")
                conteudo = meu_disquete.carregar(name)
                escrever(f"Conteúdo carregado: \n{conteudo}\n")
                enter()
            elif rr == "6":
                enter("pressione enter para deletar...")
                meu_disquete.ejetar()
                enter()
            elif rr == "7":
                namedisk = input("Insira o nome do disquete> ")
                editor_simples(namedisk)
            elif rr == "8":
                horizon_assistant()
            elif rr == "9":
                navegador()
            elif rr == "10":
                sys.exit()
            else:
                escrever("Comando não reconhecido! tente novamente.", "RED", "destaque")
                enter()
                limpar()

if __name__ == "__main__":
    try:
        debug2()
    except Exception as e:
        escrever("[ERRO DETECTADO]")
        input()