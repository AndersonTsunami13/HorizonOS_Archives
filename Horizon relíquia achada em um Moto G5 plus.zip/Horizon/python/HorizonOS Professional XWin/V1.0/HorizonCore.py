from datetime import datetime
import os, sys, time

from info import *
from font import escrever, limpar, enter