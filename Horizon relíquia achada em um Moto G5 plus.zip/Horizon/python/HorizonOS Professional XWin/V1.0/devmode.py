# devmode.py

import sys, os, random

from font import escrever, limpar, enter, input_silencioso
from info import *
from InfinixOS_Modules import escrever_log
    
def enable_devmode(): # modo_dev
    r = input("Insira a senha do devmode: ")
    if r == senha_devmode:
        modo_dev = True
        escrever("Devmode desbloqueado com sucesso! Use com responsabilidade (⁠ ͡⁠°⁠ ͜⁠ʖ⁠ ͡⁠°⁠)", "GREEN")
        enter()
    else:
        escrever("Falha aí ativar o devmode...")
    
def status_devmode():
    if modo_dev:
        escrever("O modo Dev está ativado!", "GREEN", "destaque")
    else:
        escrever("O modo Dev está desativado!", "RED", "destaque")
    enter()

def devmode_mod_var(comando):
    # comando esperado: "mod V: NOME_VARIAVEL = VALOR"
    try:
        if not comando.startswith("mod V:"):
            escrever("Comando inválido.")
            return
        
        parte_util = comando.replace("mod V:", "").strip()
        
        nome_var, valor = parte_util.split("=")
        nome_var = nome_var.strip()
        valor = valor.strip()

        # Tenta converter para inteiro, float ou mantem string
        if valor.isdigit():
            valor = int(valor)
        else:
            try:
                valor = float(valor)
            except ValueError:
                valor = valor.strip('"').strip("'")  # tira aspas se tiver

        # Verifica se a variável existe na classe
        if hasattr(vgh, nome_var):
            setattr(vgh, nome_var, valor)
            escrever(f"Variável {nome_var} modificada para {valor}", "GREEN")
            escrever_log(f"Variável {nome_var} modificada para {valor} no DevMode", "log3.txt")
        else:
            escrever(f"A variável '{nome_var}' não existe em vgh.", "RED")
    except Exception as e:
        escrever(f"Erro ao modificar variável: {e}", "RED")
        
def mostrar_codigo_fonte():
    aviso = """
⚠️ Aviso: O código fonte é grande e pode travar seu terminal.
Deseja continuar? (S/N)
"""
    resposta = input(aviso).strip().upper()
    if resposta != "S":
        escrever("Operação cancelada.")
        return

    arquivo_codigo = __file__  # pega o nome do arquivo atual
    try:
        with open(arquivo_codigo, "r", encoding="utf-8") as f:
            linhas = f.readlines()

        bloco = 20
        total = len(linhas)
        for i in range(0, total, bloco):
            for linha in linhas[i:i+bloco]:
                escrever(linha.rstrip())
            if i + bloco < total:
                input("\nPressione Enter para continuar...")
    except Exception as e:
        escrever(f"Erro ao ler o código fonte: {e}")
        
    
def devmode():
    global usuario
    limpar()
    name_teg_dev = random.choice(name_tegs_system_dev)
    usuariodev = random.choice(name_DEV)
    while True:
        try:
            comando = input(f"{usuariodev}{name_teg_dev}> ").strip().lower()
            if comando:           
                escrever_log(f"comando: {comando} Inserido.", "log3.txt")
                #executar_comando(comando)
                escrever("Desculpe, os comandos não pode ser executado ainda!", "MAGENTA")
        except KeyboardInterrupt:
            escrever("\nSistema interrompido pelo usuário.", "RED")
            break
            
if __name__ == "__main__":
    while True:
        limpar()
        escrever("~" * 35, "YELLOW")
        escrever(">>> Horizon: Devmode", "YELLOW")
        escrever("~" * 35, "YELLOW")
        escrever(f"{name_ui_apps} - {version_ui_apps}", "BLUE", "destaque")
        escrever("\n[1] Ativar devmode")
        escrever("[2] Status do Devmode")
        escrever("[3] Editar variáveis")
        escrever("[4] Ver código-fonte")
        escrever("[5] Acessar devmode")
        escrever("[6] Sair")
        opc = input("> ")
        if opc == "1":
            enable_devmode()
        elif opc == "2":
            status_devmode()
        elif opc == "3":
            escrever("#mod V: NOME_VARIAVEL = VALOR\n", "CYAN", "destaque")
            comando = input(">")
            devmode_mod_var(comando)
        elif opc == "4":
            mostrar_codigo_fonte()
        elif opc == "5":
            devmode()
        elif opc == "6":
            sys.exit()
        else:
            escrever("Opção inválida!", "RED")