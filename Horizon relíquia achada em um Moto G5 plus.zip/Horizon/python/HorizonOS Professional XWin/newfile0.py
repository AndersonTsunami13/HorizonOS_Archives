import time
import os
import random

def limpar():
    os.system("cls" if os.name == "nt" else "clear")

# Dicionário de frases psicológicas
frases = {
    1: "No frio da noite, será que você está sozinho?",
    2: "O tempo passa. Você percebe?",
    3: "Nem toda presença faz barulho.",
    4: "Você confia no silêncio?",
    5: "Enquanto você observa, algo observa você."
}

# Inicializa
ultima_troca = time.strftime("%M")
frase_atual = random.choice(list(frases.values()))

while True:
    limpar()

    hora_atual = time.strftime("%H:%M:%S")
    minuto_atual = time.strftime("%M")

    # Troca a frase a cada minuto
    if minuto_atual != ultima_troca:
        frase_atual = random.choice(list(frases.values()))
        ultima_troca = minuto_atual

    print("=== GHOST CLOCK ===\n")
    print(f"[ {hora_atual} ]\n")
    print(frase_atual)

    time.sleep(1)