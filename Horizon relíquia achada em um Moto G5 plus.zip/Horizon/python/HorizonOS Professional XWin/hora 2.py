import tkinter as tk
from datetime import datetime

b = 40
direcao = 1

def atualizar():
    global b, direcao

    agora = datetime.now()

    # relógio piscando
    if agora.second % 2 == 0:
        hora = agora.strftime("%H:%M:%S")
    else:
        hora = agora.strftime("%H %M %S")

    label.config(text=hora)

    # data canto inferior esquerdo
    data = agora.strftime("%d/%m/%Y")
    label_data.config(text=data)

    # título com hora
    janela.title("Relógio Horizon - " + agora.strftime("%H:%M:%S"))

    # animação do azul
    b += direcao

    if b >= 120:
        direcao = -1
    elif b <= 40:
        direcao = 1

    cor = f"#1010{b:02x}"

    janela.config(bg=cor)
    label.config(bg=cor, fg="#00aaff")
    label_data.config(bg=cor, fg="#7fdfff")

    janela.after(500, atualizar)


janela = tk.Tk()
janela.geometry("300x120")

label = tk.Label(janela, font=("Arial", 30))
label.pack(expand=True)

# data inferior esquerda
label_data = tk.Label(janela, font=("Arial", 10))
label_data.place(x=5, y=100)

atualizar()
janela.mainloop()