import tkinter as tk

def mostrar_notificacao(texto="⚡Alerta: Seu código tá brabo demais!", tempo=3000):
    notificacao = tk.Tk()
    notificacao.overrideredirect(True)  # Tira a borda da janela
    notificacao.attributes("-topmost", True)  # Fica sempre por cima
    notificacao.configure(bg="black")

    # Tamanho da notificação e estilo
    largura = 450
    altura = 80

    # Posição no canto inferior direito
    largura_tela = notificacao.winfo_screenwidth()
    altura_tela = notificacao.winfo_screenheight()
    x = largura_tela - largura - 10
    y = altura_tela - altura - 50

    notificacao.geometry(f"{largura}x{altura}+{x}+{y}")

    # Texto da notificação
    label = tk.Label(notificacao, text=texto, bg="black", fg="white", font=("Arial", 12))
    label.pack(padx=10, pady=10)

    # Fecha após o tempo definido (em milissegundos)
    notificacao.after(tempo, notificacao.destroy)

    notificacao.mainloop()

# Chama a notificação
mostrar_notificacao("⚠ janela de teste de notificaçao numero 1.")
