import pygame
import random
import sys

pygame.init()

# Tela
largura, altura = 480, 640
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Tap Tap Colors 🎨")

# Cores possíveis (R, G, B)
cores = {
    "VERMELHO": (255, 0, 0),
    "VERDE": (0, 255, 0),
    "AZUL": (0, 0, 255),
    "AMARELO": (255, 255, 0)
}

# Botões - retângulos na tela
tam_btn = 120
espaco = 20
botoes = {}
pos_x = (largura - (4 * tam_btn + 3 * espaco)) // 2
pos_y = altura // 2

for i, cor in enumerate(cores):
    rect = pygame.Rect(pos_x + i * (tam_btn + espaco), pos_y, tam_btn, tam_btn)
    botoes[cor] = rect

# Fonte e variáveis do jogo
fonte = pygame.font.SysFont("Arial", 36)
clock = pygame.time.Clock()
fps = 30

# Jogo
pontos = 0
tempo_restante = 3000  # milissegundos para tocar
velocidade = 1.0  # multiplicador para acelerar o tempo
jogo_rodando = True

# Cor alvo atual
alvo = random.choice(list(cores.keys()))
ultimo_tick = pygame.time.get_ticks()

while jogo_rodando:
    agora = pygame.time.get_ticks()
    delta = agora - ultimo_tick

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            jogo_rodando = False
        if evento.type == pygame.MOUSEBUTTONDOWN:
            toque = pygame.mouse.get_pos()
            # Checa se tocou no botão correto
            if botoes[alvo].collidepoint(toque):
                pontos += 1
                # Escolhe nova cor
                alvo = random.choice(list(cores.keys()))
                tempo_restante = int(3000 / velocidade)
                velocidade *= 1.05  # fica mais rápido
                ultimo_tick = agora
            else:
                # Toque no botão errado: game over
                jogo_rodando = False

    # Se o tempo acabar, game over
    if delta > tempo_restante:
        jogo_rodando = False

    # Tela
    tela.fill((30, 30, 30))
    pygame.draw.rect(tela, (255, 255, 255), (0, 0, largura, altura), 3)

    # Desenhar os botões
    for cor, rect in botoes.items():
        pygame.draw.rect(tela, cores[cor], rect)
        if cor == alvo:
            # Marca o botão alvo com uma borda branca
            pygame.draw.rect(tela, (255, 255, 255), rect, 5)

    # Texto pontos e tempo
    texto_pontos = fonte.render(f"Pontos: {pontos}", True, (255, 255, 255))
    tela.blit(texto_pontos, (20, 20))

    tempo_texto = fonte.render(f"Tempo: {max(0, (tempo_restante - delta)//1000 + 1)}", True, (255, 255, 255))
    tela.blit(tempo_texto, (largura - 150, 20))

    pygame.display.update()
    clock.tick(fps)

# Game over
tela.fill((30, 30, 30))
texto_game_over = fonte.render("Game Over!", True, (255, 0, 0))
texto_final = fonte.render(f"Pontuação final: {pontos}", True, (255, 255, 255))
tela.blit(texto_game_over, (largura//2 - texto_game_over.get_width()//2, altura//2 - 40))
tela.blit(texto_final, (largura//2 - texto_final.get_width()//2, altura//2 + 10))
pygame.display.update()
pygame.time.wait(3000)

pygame.quit()
sys.exit()