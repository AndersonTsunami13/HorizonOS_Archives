import random
import time
import tkinter as tk
from tkinter import simpledialog, messagebox

# Definição dos níveis
levels = {
    "Fácil": (20, 2, 45),
    "Médio": (40, 5, 60),
    "Difícil": (60, 8, 90),
    "Mestre": (80, 14, 120),
    "Professional": (100, 5, 200),
    "God": (120, 15, 300),
    "Hacker": (160, 10, 460),
    "Invincible": (200, 30, 600)
}

# Tkinter setup
root = tk.Tk()
root.withdraw()  # não mostra janela principal

# Nome
nome = simpledialog.askstring("Nome", "Digite seu nome, meu nobre:")
if not nome:
    nome = "Sem nome"
messagebox.showinfo("Boas-vindas", f"Olá, {nome} 👀🔥")

# Escolha de modo
modo = simpledialog.askstring("Modo", "Escolha um nível específico ou 'progressivo':")
if modo:
    modo = modo.capitalize()
else:
    modo = "Fácil"

if modo != "Progressivo":
    if modo not in levels:
        messagebox.showinfo("Aviso", "Nível inválido, iniciando Fácil automaticamente 😏")
        modo = "Fácil"
    total_questoes, min_num, max_num = levels[modo]
else:
    modo = "Progressivo"
    total_questoes, min_num, max_num = 20, 2, 45

# Contadores
score = 0
streak = 0
questao_count = 0
erros = 0

start_time = time.time()

while questao_count < total_questoes:
    # Modo progressivo
    if modo == "Progressivo":
        if questao_count < 20: min_num, max_num = 2, 45
        elif questao_count < 40: min_num, max_num = 5, 60
        elif questao_count < 60: min_num, max_num = 8, 90
        elif questao_count < 80: min_num, max_num = 14, 120
        elif questao_count < 100: min_num, max_num = 5, 200
        elif questao_count < 120: min_num, max_num = 15, 300
        elif questao_count < 160: min_num, max_num = 10, 460
        else: min_num, max_num = 30, 600

    num1 = random.randint(min_num, max_num)
    num2 = random.randint(min_num, max_num)
    op = random.choice(["+", "-", "*", "/"])

    if op == "/":
        num1 = num1 * num2  # garante divisão exata

    # Input via diálogo
    resposta = simpledialog.askstring("Questão", f"{num1} {op} {num2} = (ou digite 'sair')")

    if resposta is None or resposta.lower() == "sair":
        break

    try:
        resposta = float(resposta)
    except:
        messagebox.showwarning("Ops", "Entrada inválida, tente novamente 😏")
        continue

    correta = eval(f"{num1}{op}{num2}")
    if resposta == correta:
        if op in ["+", "-"]:
            pontos = int((num1 + num2)/2)
        elif op == "*":
            pontos = int((num1*num2)/10)
        else:
            pontos = int(max(num1,num2)/min(num1,num2))
        score += pontos
        streak += 1
        messagebox.showinfo("Resultado", f"✅ Acertou! +{pontos} pontos\nScore: {score}\nStreak: {streak}")
    else:
        streak = 0
        erros += 1
        messagebox.showerror("Errou!", f"❌ Resposta certa: {correta}\nScore: {score}\nStreak resetado")

        if erros == 1:
            messagebox.showinfo("Dica", "💡 Errar é humano, aguenta que você consegue 😏")
        elif 2 <= erros <= 10:
            messagebox.showinfo("Motivação", "➡️ Segue em frente, brother!")
        elif 11 <= erros <= 15:
            messagebox.showinfo("👀", f"( ͡° ͜ʖ ͡°) de boa, to observando {nome}")
        elif 16 <= erros <= 22:
            messagebox.showinfo("Zoeira", "👀 Oloko! Acho que tem gente melhor no pacote 📦")
        elif 23 <= erros <= 29:
            messagebox.showinfo("Alerta", ":( Sistema vai morrer daqui a pouco...")
        elif erros == 30:
            for i in range(5):  # reduzi pra não travar celular
                janela = tk.Toplevel()
                janela.title(f"Você é um idiota {i+1}")
                tk.Label(janela, text="Você errou 30 vezes 😏☠️", font=("Arial", 16), fg="red").pack(padx=20, pady=20)
                janela.geometry("300x100+{}+{}".format(100+i*10,100+i*10))
                janela.after(3000, janela.destroy)
            messagebox.showinfo("💀", "Sistema troll ativado...")
        elif erros >= 31:
            blackout = tk.Toplevel()
            blackout.configure(bg="black")
            blackout.attributes("-fullscreen", True)
            tk.Label(blackout, text="Game Over 😈", font=("Arial", 40), fg="red", bg="black").pack(expand=True)
            blackout.after(4000, blackout.destroy)
            break

    questao_count += 1

end_time = time.time()
tempo_total = end_time - start_time
minutos = int(tempo_total // 60)
segundos = int(tempo_total % 60)

messagebox.showinfo("Fim de jogo",
    f"Fim de jogo, {nome} 🖤🔥\n\nPontuação final: {score}\nQuestões respondidas: {questao_count}\nTempo total: {minutos}m {segundos}s")

root.destroy()