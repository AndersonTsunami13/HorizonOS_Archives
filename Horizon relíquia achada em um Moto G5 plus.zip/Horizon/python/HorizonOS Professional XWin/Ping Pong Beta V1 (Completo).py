import pygame
import sys

# Ping Pong Beta V1
# Desenvolvedor Anderson Tsunami
# Jogo para HorizonOS

pygame.init()

# Tamanho da janela
largura = 800
altura = 600
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Pong Mobile Solo Edition")

# Cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
CINZA = (200, 200, 200)

# Raquetes
raquete_largura = 10
raquete_altura = 100
raquete1_y = altura // 2 - raquete_altura // 2
raquete2_y = altura // 2 - raquete_altura // 2

# Bola
bola_x = largura // 2
bola_y = altura // 2
bola_raio = 10
velocidade_bola_x = 4
velocidade_bola_y = 4

# Velocidade
velocidade_raquete = 28

# Placar
placar1 = 0
placar2 = 0
fonte = pygame.font.SysFont("Arial", 30)

# Botões (retângulos invisíveis de toque)
botao_cima = pygame.Rect(0, 0, 100, altura // 2)
botao_baixo = pygame.Rect(0, altura // 2, 100, altura // 2)

clock = pygame.time.Clock()

# Loop do jogo
while True:
    tela.fill(PRETO)
    pygame.draw.rect(tela, BRANCO, (0, 0, largura, altura), 3)

    # Eventos
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif evento.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if botao_cima.collidepoint(pos):
                raquete1_y -= velocidade_raquete
            elif botao_baixo.collidepoint(pos):
                raquete1_y += velocidade_raquete

    # Movimento da bola
    bola_x += velocidade_bola_x
    bola_y += velocidade_bola_y

    # Colisão com topo/baixo
    if bola_y <= 0 or bola_y >= altura:
        velocidade_bola_y *= -1

    # Colisão com raquetes
    if bola_x <= 20 and raquete1_y < bola_y < raquete1_y + raquete_altura:
        velocidade_bola_x *= -1
    if bola_x >= largura - 20 and raquete2_y < bola_y < raquete2_y + raquete_altura:
        velocidade_bola_x *= -1

    # Pontuação
    if bola_x < 0:
        placar2 += 1
        bola_x, bola_y = largura // 2, altura // 2
    if bola_x > largura:
        placar1 += 1
        bola_x, bola_y = largura // 2, altura // 2

    # --- Bot automático controla raquete2 (direita)
    if raquete2_y + raquete_altura // 2 < bola_y:
        raquete2_y += velocidade_raquete - 2
    elif raquete2_y + raquete_altura // 2 > bola_y:
        raquete2_y -= velocidade_raquete - 2

    # Desenhar raquetes, bola e botões
    pygame.draw.rect(tela, BRANCO, (10, raquete1_y, raquete_largura, raquete_altura))
    pygame.draw.rect(tela, BRANCO, (largura - 20, raquete2_y, raquete_largura, raquete_altura))
    pygame.draw.circle(tela, BRANCO, (bola_x, bola_y), bola_raio)

    # Botões de toque (apenas desenhando pra mostrar onde estão)
    pygame.draw.rect(tela, CINZA, botao_cima, 2)
    pygame.draw.rect(tela, CINZA, botao_baixo, 2)
    tela.blit(fonte.render("", True, BRANCO), (30, 100))
    tela.blit(fonte.render("", True, BRANCO), (30, 300))

    # Placar
    texto = fonte.render(f"{placar1}  x  {placar2}", True, BRANCO)
    tela.blit(texto, (largura // 2 - 50, 20))

    pygame.display.flip()
    clock.tick(60)