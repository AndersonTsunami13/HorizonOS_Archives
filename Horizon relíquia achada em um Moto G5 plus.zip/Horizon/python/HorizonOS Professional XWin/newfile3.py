import sys
import os

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, RAIZ)

from system.font import *
from modules.log import escrever_log

import os
from datetime import datetime

PASTA_LOGS = "logs"
LOG_FILE = "LogX.log"

# raiz do projeto (um nível acima da pasta modules)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG_DIR = os.path.join(BASE_DIR, PASTA_LOGS)

def escrever_log(texto, nivel="0"):
    agora = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    niveis = {
        "0": "information",
        "1": "alert",
        "2": "warning",
        "3": "danger",
        "4": "message",
        "5": "error"
    }

    nn = niveis.get(nivel, "information")

    # garante a pasta logs na RAIZ
    os.makedirs(LOG_DIR, exist_ok=True)

    caminho_log = os.path.join(LOG_DIR, LOG_FILE)

    with open(caminho_log, "a", encoding="utf-8") as arquivo:
        arquivo.write(f"[HNDX] [{nn}] [{agora}] {texto}\n")