import tkinter as tk
from tkinter import messagebox

# Função que será chamada quando pressionar a tecla F1
def acao_f1(event):
    messagebox.showerror("Erro", "Não foi possivel acessar as informações necessarias. errorcode:?")
    # Aqui você pode colocar qualquer ação que queira para a tecla F1

def acao_f2(event):
    messagebox.showwarning("Erro", "Os arquivos de informações nao estao visiveis no sistema de...")
    # Aqui você pode colocar qualquer ação que queira para a tecla F1

def acao_f3(event):
    messagebox.showinfo("aviso inportante!", "esse erros podem ser comuns em versoes betas. sertifique sua versao anrtes de qualquer coisa!")
    # Aqui você pode colocar qualquer ação que queira para a tecla F1

# Configuração da janela principal
janela = tk.Tk()
janela.title("Janela com Ação para F1")
janela.geometry("400x300")

# Bind para a tecla F1
janela.bind("<F1>", acao_f1)
janela.bind("<F2>", acao_f2)
janela.bind("<F3>", acao_f3)

# Botão de exemplo
botao = tk.Button(janela, text="Clique aqui", command=lambda: print("Botão pressionado"))
botao.pack(pady=20)

# Iniciar a interface gráfica
janela.mainloop()
