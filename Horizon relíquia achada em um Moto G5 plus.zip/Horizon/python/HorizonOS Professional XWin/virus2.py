import os
import time
import random

# Pergunta quantas janelas deseja abrir
quantidade = input("Quantas janelas CMD deseja abrir? (Ex: 5, 10, 20) ")

# Nome do arquivo BAT temporário
arquivo_bat = "idiota.bat"

# Lista de cores para mudar aleatoriamente (CMD aceita de 0 a F)
cores = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "0A", "0B", "0C", "0D", "0E", "0F"]

# Comandos do CMD para piscar a mensagem mais rapido e mudar cor
comandos = """
@echo off
title ERRO FATAL
mode con: cols=40 lines=5

:loop
cls
color {cor}
echo VOCE E UM IDIOTA!!!
timeout /t 0 >nul
cls
timeout /t 0 >nul
goto loop
"""

# Criar o arquivo BAT temporário
with open(arquivo_bat, "w") as f:
    f.write(comandos.format(cor=random.choice(cores)))

# Executar várias instâncias do BAT
for _ in range(int(quantidade)):
    os.system(f"start {arquivo_bat}")

# Espera um tempo e apaga o arquivo BAT (opcional)
time.sleep(10)
os.remove(arquivo_bat)
